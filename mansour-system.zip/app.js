'use strict';
/* ===================== نظام شركة المنصور — الواجهة ===================== */
const C = window.APP_CONFIG;
const sb = supabase.createClient(C.url, C.key);
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = n => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '-' + Math.random());
const today = () => new Date().toISOString().slice(0, 10);
const fdate = d => d ? new Date(d).toLocaleString('ar-IQ', { dateStyle: 'short', timeStyle: 'short' }) : '';
let ME = null, VIEW = 'home', SITES = [];

const ROLES = { owner: 'المالك', developer: 'مطوّر', project_manager: 'مدير المشروع', gm1: 'المدير العام الأول', gm2: 'المدير العام الثاني', project_admin: 'مسؤول إدارة المشروع', dept_electric: 'قسم الكهرباء', dept_mech: 'قسم الميكانيك', dept_vehicles: 'قسم الآليات', store_main: 'المخزن الرئيسي', store_vehicles: 'مخزن الآليات', storekeeper: 'أمين المخزن', receiver: 'مستلم المواد', prep: 'التجهيز', purchasing_head: 'مسؤول المشتريات', buyer: 'المشتري', operator: 'المشغّل', driver: 'السائق', mechanic: 'الميكانيكي', fuel_officer: 'مسؤول الوقود', security: 'الأمنية', foreman: 'الفورمن', attendance_clerk: 'مسجّل الحضور', engineer: 'المهندس', contractor: 'المقاول', accounts_head: 'مسؤول الحسابات', disbursement: 'مسؤولة الصرف', sales_head: 'مسؤول المبيعات', sales_staff: 'موظف المبيعات', pending: 'بانتظار الموافقة' };
const ADMIN = ['project_manager', 'gm1', 'gm2', 'project_admin'];
const DEPT = ['dept_electric', 'dept_mech', 'dept_vehicles'];
const STORE = ['store_main', 'store_vehicles', 'storekeeper', 'receiver', 'prep'];
const PURCH = ['purchasing_head', 'buyer'];
const VEH = ['operator', 'driver', 'mechanic', 'fuel_officer', 'security', 'store_vehicles', 'dept_vehicles', 'prep'];
const ATT = ['foreman', 'attendance_clerk', 'engineer', 'contractor', 'project_admin'];
const SALES = ['sales_head', 'sales_staff'];
const isOwner = () => ME && ['owner', 'developer'].includes(ME.role);
const hasRole = (rs) => isOwner() || (rs === 'all') || rs.includes(ME.role);

/* ---------- أدوات عامة ---------- */
function toast(msg, ms = 2800) {
  const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
  document.body.appendChild(t); setTimeout(() => t.remove(), ms);
}
function errMsg(e) {
  if (!e) return '';
  if (e.code === '23505') return 'انحفظ من قبل (تكرار)';
  if (e.code === '42501') return 'ما عندك صلاحية لهذا الإجراء';
  return e.message || String(e);
}
async function run(p, okMsg) {
  const r = await p;
  if (r.error) { toast('⚠ ' + errMsg(r.error), 4500); return null; }
  if (okMsg) toast(okMsg);
  return r.data ?? true;
}
function notify(title, body) { sb.from('notifications').insert({ site_id: ME.site_id, title, body, kind: 'info' }); }
function norm(s) {
  return String(s || '').toLowerCase().replace(/[\u064B-\u0652ـ]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/\s+/g, ' ').trim();
}
function nameScore(a, b) {
  const A = norm(a).split(' '), B = norm(b).split(' ');
  if (!A[0] || !B[0]) return 0;
  const hit = A.filter(x => B.some(y => y === x || (x.length > 2 && y.length > 2 && (x.startsWith(y) || y.startsWith(x))))).length;
  return hit / Math.max(A.length, B.length);
}
const phoneWA = p => { p = String(p || '').replace(/\D/g, ''); return p.startsWith('0') ? '964' + p.slice(1) : p; };

async function upload(file) {
  const ext = (file.name.split('.').pop() || 'jpg').replace(/\W/g, '');
  const p = `${ME.site_id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const { error } = await sb.storage.from(C.bucket).upload(p, file);
  if (error) throw error;
  return sb.storage.from(C.bucket).getPublicUrl(p).data.publicUrl;
}
function toB64(file) {
  return new Promise((res, rej) => {
    if (!file.type.startsWith('image/')) { const r = new FileReader(); r.onload = () => res({ data: r.result.split(',')[1], type: file.type }); r.onerror = rej; r.readAsDataURL(file); return; }
    const img = new Image(), u = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, 1600 / Math.max(img.width, img.height));
      const cv = document.createElement('canvas'); cv.width = img.width * k; cv.height = img.height * k;
      cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
      res({ data: cv.toDataURL('image/jpeg', .85).split(',')[1], type: 'image/jpeg' }); URL.revokeObjectURL(u);
    };
    img.onerror = rej; img.src = u;
  });
}
// قراءة بالذكاء الاصطناعي. twice=true → قراءتين ومقارنة (للحضور والكاز)
async function aiRead(kind, file, twice = false) {
  const b = await toB64(file);
  const call = () => sb.functions.invoke('ai-read', { body: { kind, data: b.data, media_type: b.type } });
  const [a, c] = twice ? await Promise.all([call(), call()]) : [await call(), null];
  if (a.error) throw new Error('فشلت القراءة: ' + (a.error.message || ''));
  return { result: a.data, second: c && c.data, agree: c ? JSON.stringify(a.data) === JSON.stringify(c.data) : true };
}

/* ---------- نموذج عام (نافذة) ---------- */
const refCache = {};
async function refOpts(table, lab = 'name', filter) {
  const key = table + lab;
  if (!refCache[key] || refCache[key].t < Date.now() - 20000) {
    let q = sb.from(table).select('*').limit(1000); if (filter) q = filter(q);
    const { data } = await q; refCache[key] = { t: Date.now(), d: data || [] };
  }
  return refCache[key].d.map(r => [r.id, typeof lab === 'function' ? lab(r) : r[lab]]);
}
function modal(html) {
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<div>${html}</div>`;
  m.addEventListener('click', e => { if (e.target === m) m.remove(); });
  document.body.appendChild(m); return m;
}
async function openForm({ title, fields, init = {}, save, extra = '', onReady }) {
  for (const f of fields) if (f.t === 'ref') f.opts = await refOpts(f.ref, f.lab || 'name', f.filter);
  const token = uid();
  const row = f => {
    const v = init[f.k] ?? f.def ?? '';
    const id = 'f_' + f.k;
    let inp;
    if (f.t === 'select' || f.t === 'ref') inp = `<select id="${id}">${f.t === 'ref' || !f.req ? '<option value="">—</option>' : ''}${(f.opts || []).map(([a, b]) => `<option value="${esc(a)}" ${String(a) === String(v) ? 'selected' : ''}>${esc(b)}</option>`).join('')}</select>`;
    else if (f.t === 'area') inp = `<textarea id="${id}">${esc(v)}</textarea>`;
    else if (f.t === 'check') inp = `<input type="checkbox" id="${id}" ${v ? 'checked' : ''}>`;
    else if (f.t === 'photo') inp = `<input type="file" id="${id}" accept="image/*,application/pdf" capture="environment">`;
    else inp = `<input id="${id}" type="${f.t || 'text'}" value="${esc(v)}" ${f.t === 'number' ? 'inputmode="decimal" step="any"' : ''}>`;
    return `<label>${esc(f.label)}${f.req ? ' *' : ''}</label>${inp}`;
  };
  const m = modal(`<h3>${esc(title)}</h3>${extra}${fields.map(row).join('')}<div class="row" style="margin-top:12px"><button class="btn" id="fsave">حفظ</button><button class="btn sec" id="fcancel">إلغاء</button></div><div class="err" id="ferr"></div>`);
  $('#fcancel', m).onclick = () => m.remove();
  const read = async () => {
    const o = {};
    for (const f of fields) {
      const el = $('#f_' + f.k, m);
      if (f.t === 'check') o[f.k] = el.checked;
      else if (f.t === 'photo') o[f.k] = el.files[0] ? await upload(el.files[0]) : (init[f.k] || null);
      else if (f.t === 'number') o[f.k] = el.value === '' ? null : Number(el.value);
      else o[f.k] = el.value === '' ? null : el.value;
      if (f.req && (o[f.k] === null || o[f.k] === '')) throw new Error('عبّي: ' + f.label);
    }
    return o;
  };
  $('#fsave', m).onclick = async function () {
    this.disabled = true; $('#ferr', m).textContent = '';
    try { const o = await read(); o.client_token = token; const ok = await save(o, m); if (ok !== false) m.remove(); else this.disabled = false; }
    catch (e) { $('#ferr', m).textContent = errMsg(e); this.disabled = false; }
  };
  if (onReady) onReady(m);
  return m;
}

/* ---------- جدول عام ---------- */
function table(cols, rows, actions) {
  return `<div class="tw"><table><thead><tr>${cols.map(c => `<th>${esc(c[1])}</th>`).join('')}${actions ? '<th></th>' : ''}</tr></thead><tbody>${rows.map((r, i) =>
    `<tr>${cols.map(c => `<td>${c[2] ? c[2](r[c[0]], r) : esc(r[c[0]])}</td>`).join('')}${actions ? `<td>${actions(r, i)}</td>` : ''}</tr>`).join('') || `<tr><td colspan="${cols.length + 1}" class="mut">ما كو بيانات</td></tr>`}</tbody></table></div>`;
}
const tag = (t, c = '') => `<span class="tag ${c}">${esc(t)}</span>`;

/* موديول عام CRUD */
function crud(cfg) {
  return async function (root) {
    const load = async () => {
      let q = sb.from(cfg.table).select(cfg.select || '*').order(cfg.order || 'created_at', { ascending: false }).limit(300);
      if (cfg.filter) q = cfg.filter(q);
      const { data, error } = await q;
      if (error) { root.innerHTML = `<div class="card err">${esc(errMsg(error))}</div>`; return; }
      draw(data || []);
    };
    const draw = rows => {
      root.innerHTML = `<div class="card"><div class="row"><h3 style="flex:1;margin:0">${cfg.title}</h3>${cfg.add !== false && (!cfg.addRoles || hasRole(cfg.addRoles)) ? '<button class="btn" id="add">+ جديد</button>' : ''}${(cfg.buttons || []).map((b, i) => `<button class="btn sec" data-b="${i}">${b.label}</button>`).join('')}</div>
        ${cfg.top ? cfg.top(rows) : ''}<input id="q" placeholder="بحث..." style="margin:8px 0"><div id="tb"></div></div>`;
      const paint = () => {
        const q = norm($('#q', root).value);
        const f = rows.filter(r => !q || norm(JSON.stringify(Object.values(r))).includes(q));
        $('#tb', root).innerHTML = table(cfg.cols, f, r => {
          let s = '';
          if (cfg.edit !== false) s += `<button class="btn sec" data-e="${r.id}">تعديل</button> `;
          (cfg.rowBtns || []).forEach((b, i) => { if (!b.show || b.show(r)) s += `<button class="btn sec" data-r="${i}|${r.id}">${b.label}</button> `; });
          if (isOwner() && cfg.del !== false) s += `<button class="btn red" data-d="${r.id}">حذف</button>`;
          return s;
        });
        root.querySelectorAll('[data-e]').forEach(b => b.onclick = () => edit(rows.find(r => r.id === b.dataset.e)));
        root.querySelectorAll('[data-d]').forEach(b => b.onclick = async () => { if (confirm('حذف نهائي؟')) { if (await run(sb.from(cfg.table).delete().eq('id', b.dataset.d), 'انحذف')) load(); } });
        root.querySelectorAll('[data-r]').forEach(b => b.onclick = async () => { const [i, id] = b.dataset.r.split('|'); await cfg.rowBtns[i].fn(rows.find(r => r.id === id), load); });
      };
      $('#q', root).oninput = paint; paint();
      const a = $('#add', root); if (a) a.onclick = () => edit(null);
      root.querySelectorAll('[data-b]').forEach(b => b.onclick = () => cfg.buttons[b.dataset.b].fn(rows, load));
    };
    const edit = async (rec) => {
      await openForm({
        title: (rec ? 'تعديل — ' : 'جديد — ') + cfg.title, fields: cfg.fields.map(f => ({ ...f })), init: rec || cfg.init || {},
        extra: cfg.extra ? cfg.extra(rec) : '',
        onReady: cfg.onReady,
        save: async (o) => {
          if (cfg.before) { const r = await cfg.before(o, rec); if (r === false) return false; }
          const r = rec ? await run(sb.from(cfg.table).update(o).eq('id', rec.id), 'انحفظ')
            : await run(sb.from(cfg.table).insert(o).select(), 'انحفظ');
          if (!r) return false;
          if (cfg.after) await cfg.after(o, r);
          load();
        }
      });
    };
    await load();
  };
}
const T = (k, label, extra = {}) => ({ k, label, t: 'text', ...extra });
const N = (k, label, extra = {}) => ({ k, label, t: 'number', ...extra });
const D = (k, label, extra = {}) => ({ k, label, t: 'date', ...extra });
const S = (k, label, opts, extra = {}) => ({ k, label, t: 'select', opts, ...extra });
const A = (k, label) => ({ k, label, t: 'area' });
const P = (k, label) => ({ k, label, t: 'photo' });
const R = (k, label, ref, lab, extra = {}) => ({ k, label, t: 'ref', ref, lab, ...extra });
const BUILDINGS = Array.from({ length: 22 }, (_, i) => ['T' + (i + 1), 'T' + (i + 1)]);
const bld = S('building', 'البناية', [['', '—'], ...BUILDINGS]);
const link = u => u ? `<a href="${esc(u)}" target="_blank">📎</a>` : '';

/* ===================== المخازن ===================== */
const mMaterials = crud({
  title: 'المواد والرصيد', table: 'materials', order: 'name',
  cols: [['name', 'المادة'], ['qty', 'الرصيد', fmt], ['unit', 'الوحدة'], ['store', 'المخزن', v => v === 'main' ? 'رئيسي' : 'آليات'], ['building', 'البناية'], ['notes', 'ملاحظات']],
  fields: [T('name', 'اسم المادة', { req: 1 }), T('unit', 'الوحدة', { def: 'قطعة' }), S('store', 'المخزن', [['main', 'المخزن الرئيسي'], ['vehicles', 'مخزن الآليات']], { req: 1 }), N('qty', 'الرصيد الافتتاحي', { def: 0 }), bld, A('notes', 'ملاحظات')],
});
const mMoves = crud({
  title: 'المدخلات والمخرجات', table: 'stock_moves', select: '*,materials(name),vehicles(name)',
  cols: [['created_at', 'الوقت', fdate], ['direction', 'النوع', v => ({ in: tag('إدخال'), out: tag('إخراج', 'amb'), repair_in: tag('إلى التصليح', 'red'), repair_out: tag('رجع من التصليح') }[v])], ['materials', 'المادة', v => esc(v?.name)], ['qty', 'الكمية', fmt], ['vehicles', 'الآلية', v => esc(v?.name || '')], ['building', 'البناية'], ['receipt_photo', 'وصل', link], ['notes', 'ملاحظات']],
  fields: [S('direction', 'النوع', [['in', 'إدخال'], ['out', 'إخراج / صرف'], ['repair_in', 'دخول للتصليح'], ['repair_out', 'خروج من التصليح']], { req: 1 }), R('material_id', 'المادة', 'materials', 'name', { req: 1 }), N('qty', 'الكمية', { req: 1 }), R('vehicle_id', 'الآلية (للصرف المباشر)', 'vehicles', 'name'), bld, P('receipt_photo', 'صورة الوصل'), A('notes', 'ملاحظات')],
  edit: false,
});
const mStocktake = crud({
  title: 'الجرد الفعلي', table: 'stocktakes', select: '*,materials(name,qty)', edit: false,
  cols: [['created_at', 'التاريخ', fdate], ['materials', 'المادة', v => esc(v?.name)], ['system_qty', 'بالنظام', fmt], ['counted', 'الفعلي', fmt], ['system_qty', 'الفرق', (v, r) => { const d = (r.counted || 0) - (r.system_qty || 0); return tag(fmt(d), d === 0 ? '' : 'red'); }], ['notes', 'ملاحظات']],
  fields: [R('material_id', 'المادة', 'materials', 'name', { req: 1 }), N('counted', 'الكمية الفعلية', { req: 1 }), A('notes', 'ملاحظات')],
  before: async (o) => { const { data } = await sb.from('materials').select('qty').eq('id', o.material_id).single(); o.system_qty = data?.qty ?? 0; },
});
const mTrucks = crud({
  title: 'الشاحنات الواصلة', table: 'incoming_trucks', edit: true,
  cols: [['created_at', 'الوصول', fdate], ['plate', 'اللوحة'], ['supplier', 'المورد'], ['material', 'المادة'], ['qty', 'الكمية', fmt], ['state', 'الحالة', v => v === 'unloaded' ? tag('نُزّلت') : tag('واصلة', 'amb')], ['receipt_photo', 'وصل', link]],
  fields: [T('plate', 'رقم الشاحنة'), T('supplier', 'المورد'), T('material', 'المادة'), N('qty', 'الكمية'), S('state', 'الحالة', [['arrived', 'واصلة'], ['unloaded', 'تم التنزيل']], { req: 1 }), P('receipt_photo', 'صورة الوصل')],
  rowBtns: [{ label: 'تم التنزيل', show: r => r.state !== 'unloaded', fn: async (r, load) => { if (await run(sb.from('incoming_trucks').update({ state: 'unloaded' }).eq('id', r.id), 'تم')) load(); } }],
});

/* ===================== الطلبات ===================== */
const STAGES = { submitted: ['مقدّم', 'amb'], store: ['عند المخزن', 'amb'], purchasing: ['عند المشتريات', 'red'], received: ['مستلم', ''], done: ['مكتمل', ''], rejected: ['مرفوض', 'red'] };
async function mRequests(root) {
  const load = async () => {
    const { data, error } = await sb.from('requests').select('*').order('created_at', { ascending: false }).limit(200);
    if (error) { root.innerHTML = `<div class="card err">${esc(errMsg(error))}</div>`; return; }
    const names = {}; (await sb.from('profiles').select('id,full_name')).data?.forEach(p => names[p.id] = p.full_name);
    root.innerHTML = `<div class="card"><div class="row"><h3 style="flex:1;margin:0">الطلبات</h3><button class="btn" id="n">+ طلب مادة</button><button class="btn sec" id="ai">📷 ورقة مكتوبة</button></div>
      <div id="late"></div><div id="tb"></div></div>`;
    const late = data.filter(r => ['submitted', 'store', 'purchasing'].includes(r.stage) && Date.now() - new Date(r.stage_at) > 864e5);
    if (late.length) $('#late', root).innerHTML = `<div class="warn">⏰ ${late.length} طلب متأخر أكثر من يوم بنفس المرحلة</div>`;
    $('#tb', root).innerHTML = table([['created_at', 'التاريخ', fdate], ['material', 'المادة'], ['qty', 'الكمية', (v, r) => fmt(v) + ' ' + esc(r.unit || '')], ['work_place', 'مكان العمل'], ['dept', 'القسم'], ['stage', 'وين صار هسه', (v, r) => `${tag(STAGES[v]?.[0] || v, STAGES[v]?.[1])}<div class="mut">عند: ${esc(names[r.stage_by] || '—')} · ${fdate(r.stage_at)}</div>`], ['photo', 'صورة', link]], data, r => {
      const b = [];
      const st = hasRole([...STORE, ...ADMIN]), pu = hasRole([...PURCH, ...ADMIN, 'storekeeper']);
      if (r.stage === 'submitted' && st) b.push(['store', 'استلمه المخزن']);
      if (['submitted', 'store'].includes(r.stage) && st) { b.push(['done', 'صرف من المخزن']); b.push(['purchasing', 'حوّل للمشتريات']); }
      if (r.stage === 'purchasing' && pu) b.push(['received', 'تم الشراء/الاستلام']);
      if (r.stage === 'received' && st) b.push(['done', 'إغلاق']);
      if (isOwner()) { if (!b.length && r.stage !== 'done') b.push(['done', 'إغلاق']); b.push(['rejected', 'رفض']); }
      return b.map(([s, l]) => `<button class="btn sec" data-s="${s}|${r.id}">${l}</button>`).join(' ') + ` <button class="btn sec" data-l="${r.id}">السجل</button>`;
    });
    root.querySelectorAll('[data-s]').forEach(b => b.onclick = async () => {
      const [s, id] = b.dataset.s.split('|');
      if (await run(sb.from('requests').update({ stage: s, stage_by: ME.id, stage_at: new Date().toISOString() }).eq('id', id), 'تم')) {
        await sb.from('request_log').insert({ request_id: id, stage: s });
        if (s === 'purchasing') notify('طلب محوّل للمشتريات', data.find(x => x.id === id)?.material);
        load();
      }
    });
    root.querySelectorAll('[data-l]').forEach(b => b.onclick = async () => {
      const { data: lg } = await sb.from('request_log').select('*').eq('request_id', b.dataset.l).order('at');
      modal(`<h3>مسار الطلب</h3>${table([['at', 'الوقت', fdate], ['stage', 'المرحلة', v => esc(STAGES[v]?.[0] || v)], ['by_user', 'بواسطة', v => esc(names[v] || '')]], lg || [])}`);
    });
    $('#n', root).onclick = () => newReq();
    $('#ai', root).onclick = () => {
      const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.capture = 'environment';
      i.onchange = async () => {
        toast('جاري قراءة الورقة...', 6000);
        try {
          const { result } = await aiRead('request_sheet', i.files[0]);
          const photo = await upload(i.files[0]);
          const items = result.items || [];
          if (!items.length) return toast('ما انقرت مواد');
          const m = modal(`<h3>راجع المواد المقروءة</h3><div id="it">${items.map((x, k) => `<div class="row"><input data-k="${k}" data-f="material" value="${esc(x.material)}" style="flex:3"><input data-k="${k}" data-f="qty" value="${esc(x.qty)}" style="flex:1"><input data-k="${k}" data-f="unit" value="${esc(x.unit || '')}" style="flex:1"></div>`).join('')}</div><label>مكان العمل</label><input id="wp"><div class="row" style="margin-top:10px"><button class="btn" id="ok">إرسال الطلبات</button></div>`);
          $('#ok', m).onclick = async function () {
            this.disabled = true;
            m.querySelectorAll('input[data-k]').forEach(el => items[el.dataset.k][el.dataset.f] = el.value);
            const rows = items.filter(x => x.material).map(x => ({ client_token: uid(), material: x.material, qty: Number(x.qty) || null, unit: x.unit, work_place: $('#wp', m).value, dept: ME.role, photo, from_vehicle_store: ME.role === 'dept_vehicles' || ME.role === 'store_vehicles' }));
            if (await run(sb.from('requests').insert(rows), 'انرسلت ' + rows.length + ' طلب')) { m.remove(); load(); }
          };
        } catch (e) { toast('⚠ ' + errMsg(e), 5000); }
      }; i.click();
    };
  };
  const newReq = () => openForm({
    title: 'طلب مادة', fields: [T('material', 'المادة', { req: 1 }), N('qty', 'الكمية'), T('unit', 'الوحدة'), T('work_place', 'مكان العمل'), bld, P('photo', 'صورة المادة'), A('notes', 'ملاحظات')],
    save: async (o) => { o.dept = ME.role; o.from_vehicle_store = ME.role === 'dept_vehicles' || ME.role === 'store_vehicles'; o.stage_by = ME.id; if (!(await run(sb.from('requests').insert(o), 'انرسل الطلب'))) return false; load(); },
  });
  await load();
}

/* ===================== المشتريات والفواتير ===================== */
const mSuppliers = crud({ title: 'الموردين', table: 'suppliers', order: 'name', cols: [['name', 'الاسم'], ['phone', 'الهاتف'], ['notes', 'ملاحظات']], fields: [T('name', 'الاسم', { req: 1 }), T('phone', 'الهاتف'), A('notes', 'ملاحظات')] });
const mPrices = crud({ title: 'تاريخ أسعار المواد', table: 'price_history', order: 'at', cols: [['at', 'التاريخ'], ['material', 'المادة'], ['supplier', 'المورد'], ['price', 'السعر', fmt]], fields: [T('material', 'المادة', { req: 1 }), T('supplier', 'المورد'), N('price', 'السعر', { req: 1 }), D('at', 'التاريخ', { def: today() })] });
const mInvoices = crud({
  title: 'الفواتير', table: 'invoices',
  cols: [['inv_date', 'التاريخ'], ['supplier', 'المورد'], ['invoice_no', 'الرقم'], ['total', 'المجموع', fmt], ['payment', 'الدفع', v => v === 'cash' ? 'نقد' : 'آجل'], ['building', 'البناية'], ['status', 'الحالة', v => tag({ draft: 'مسودة', review: 'بانتظار التدقيق', approved: 'معتمدة', rejected: 'مرفوضة' }[v], v === 'approved' ? '' : 'amb')], ['photo', 'صورة', link]],
  top: rows => `<div class="mut">مشترياتي: ${fmt(rows.filter(r => r.buyer === ME.id).reduce((a, r) => a + Number(r.total || 0), 0))} د.ع</div>`,
  fields: [T('supplier', 'المورد'), T('invoice_no', 'رقم الفاتورة'), D('inv_date', 'التاريخ', { def: today() }), N('total', 'المجموع'), S('payment', 'الدفع', [['cash', 'نقد'], ['credit', 'آجل']]), bld, P('photo', 'صورة الفاتورة'), A('notes', 'ملاحظات / الأسطر')],
  extra: () => `<div class="row"><button class="btn sec" id="aiinv">📷 قراءة الفاتورة بالذكاء الاصطناعي</button></div><div class="mut" id="aist"></div>`,
  onReady: (m) => {
    $('#aiinv', m).onclick = () => {
      const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.capture = 'environment';
      i.onchange = async () => {
        $('#aist', m).textContent = 'جاري القراءة...';
        try {
          const { result: r } = await aiRead('invoice', i.files[0]);
          $('#f_supplier', m).value = r.supplier || ''; $('#f_invoice_no', m).value = r.invoice_no || ''; $('#f_total', m).value = r.total || '';
          if (r.payment) $('#f_payment', m).value = r.payment === 'credit' ? 'credit' : 'cash';
          $('#f_notes', m).value = (r.lines || []).map(l => `${l.material} × ${l.qty} @ ${l.price}`).join('\n');
          m.dataset.lines = JSON.stringify(r.lines || []);
          const sum = (r.lines || []).reduce((a, l) => a + (Number(l.qty) || 0) * (Number(l.price) || 0), 0);
          $('#aist', m).innerHTML = sum && r.total && Math.abs(sum - r.total) > 1 ? `<div class="warn">⚠ مجموع الأسطر (${fmt(sum)}) ما يطابق المجموع (${fmt(r.total)})</div>` : 'انقرت — راجعها قبل الحفظ';
          const f = $('#f_photo', m); const dt = new DataTransfer(); dt.items.add(i.files[0]); f.files = dt.files;
        } catch (e) { $('#aist', m).textContent = errMsg(e); }
      }; i.click();
    };
  },
  before: async (o) => {
    const m = document.querySelector('.modal'); const lines = m?.dataset.lines ? JSON.parse(m.dataset.lines) : [];
    o.lines = lines; o.buyer = ME.id; o.status = o.status || 'review';
    if (o.invoice_no && o.supplier) { const { data } = await sb.from('invoices').select('id').eq('supplier', o.supplier).eq('invoice_no', o.invoice_no).limit(1); if (data?.length && !confirm('⚠ فاتورة مكررة (نفس المورد والرقم). تحفظ؟')) return false; }
  },
  after: async (o) => {
    for (const l of (o.lines || [])) if (l.material && l.price) await sb.from('price_history').insert({ material: l.material, supplier: o.supplier, price: l.price, client_token: uid() });
    notify('فاتورة جديدة', `${o.supplier || ''} — ${fmt(o.total)}`);
    if (o.payment === 'cash' && o.status === 'approved') await sb.from('cash_ledger').insert({ direction: 'out', category: 'مشتريات', amount: o.total, ref: 'invoice', client_token: uid() });
  },
  rowBtns: [
    { label: 'تدقيق', show: r => r.status === 'review' && hasRole(['accounts_head']), fn: async (r, load) => { if (await run(sb.from('invoices').update({ status: 'approved' }).eq('id', r.id), 'اعتُمدت')) { if (r.payment === 'cash') await sb.from('cash_ledger').insert({ direction: 'out', category: 'مشتريات', amount: r.total, ref: 'inv:' + r.id, client_token: 'inv-' + r.id }); load(); } } },
    { label: 'رفض', show: r => r.status === 'review' && hasRole(['accounts_head']), fn: async (r, load) => { if (await run(sb.from('invoices').update({ status: 'rejected' }).eq('id', r.id))) load(); } },
  ],
});
async function mGps(root) {
  const { data } = await sb.from('gps_points').select('*').order('at', { ascending: false }).limit(200);
  const names = {}; (await sb.from('profiles').select('id,full_name,role')).data?.forEach(p => names[p.id] = p);
  const last = {}; (data || []).forEach(p => { if (!last[p.user_id]) last[p.user_id] = p; });
  root.innerHTML = `<div class="card"><h3>تتبع GPS (آخر موقع)</h3>${table([['user_id', 'الشخص', v => esc(names[v]?.full_name)], ['user_id', 'الصفة', v => esc(ROLES[names[v]?.role])], ['at', 'الوقت', fdate], ['lat', 'الخريطة', (v, r) => `<a target="_blank" href="https://maps.google.com/?q=${r.lat},${r.lng}">فتح</a>`]], Object.values(last))}<div class="mut">يشتغل لحاله على موبايل المشتري والسواق عند فتح التطبيق.</div></div>`;
}

/* ===================== الآليات والوقود ===================== */
const mVehicles = crud({
  title: 'الآليات', table: 'vehicles', order: 'name',
  cols: [['name', 'الآلية'], ['plate', 'اللوحة'], ['kind', 'النوع'], ['barcode', 'الباركود'], ['status', 'الحالة', v => ({ inside: tag('داخل'), out: tag('خارج', 'amb'), loaded: tag('محمّلة', 'red') }[v])]],
  fields: [T('name', 'اسم / رقم الآلية', { req: 1 }), T('plate', 'اللوحة'), T('kind', 'النوع'), N('fuel_rate', 'المعدل اليومي للكاز (لتر)'), A('notes', 'ملاحظات')],
  buttons: [{ label: '🖨 طباعة الباركودات', fn: async (rows) => printBarcodes(rows.map(r => ({ code: r.barcode, label: r.name }))) }],
  rowBtns: [{ label: 'كلفة', fn: async (r) => openForm({ title: 'كلفة — ' + r.name, fields: [S('kind', 'النوع', [['repair', 'تصليح'], ['parts', 'قطع غيار'], ['maintenance', 'صيانة']], { req: 1 }), N('amount', 'المبلغ', { req: 1 }), N('days', 'عدد الأيام (للصيانة)'), A('notes', 'ملاحظات')], save: async (o) => { o.vehicle_id = r.id; return await run(sb.from('vehicle_costs').insert(o), 'انسجلت') ? true : false; } }) },
  { label: 'سجل الكلفة', fn: async (r) => { const { data } = await sb.from('vehicle_costs').select('*').eq('vehicle_id', r.id).order('created_at', { ascending: false }); modal(`<h3>كلفة ${esc(r.name)}</h3>${table([['created_at', 'التاريخ', fdate], ['kind', 'النوع'], ['amount', 'المبلغ', fmt], ['days', 'أيام'], ['notes', 'ملاحظات']], data || [])}<b>المجموع: ${fmt((data || []).reduce((a, x) => a + Number(x.amount || 0), 0))}</b>`); } }],
});
async function printBarcodes(items) {
  if (!window.JsBarcode) await new Promise(r => { const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js'; s.onload = r; document.head.appendChild(s); });
  const w = window.open('', '_blank');
  w.document.write(`<html dir="rtl"><body style="font-family:sans-serif"><div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">${items.map((it, i) => `<div style="border:1px solid #999;padding:6px;text-align:center"><div>${esc(it.label)}</div><svg id="b${i}"></svg></div>`).join('')}</div></body></html>`);
  items.forEach((it, i) => window.JsBarcode(w.document.getElementById('b' + i), it.code, { height: 50, fontSize: 12 }));
  setTimeout(() => w.print(), 500);
}
const mFuel = (() => {
  const base = crud({
    title: 'الكاز', table: 'fuel_logs', select: '*,vehicles(name,fuel_rate)', edit: false, addRoles: ['fuel_officer', 'store_vehicles'],
    cols: [['created_at', 'الوقت', fdate], ['direction', 'الحركة', v => v === 'in' ? tag('استلام من المحطة') : tag('تعبئة آلية', 'amb')], ['vehicles', 'الآلية', v => esc(v?.name || '')], ['liters', 'اللترات', fmt], ['station', 'المحطة'], ['price_per_liter', 'سعر اللتر', fmt]],
    top: () => `<div id="fb" class="kpi" style="margin:8px 0"><span>رصيد الخزان</span><b>…</b></div>`,
    fields: [S('direction', 'الحركة', [['out', 'تعبئة آلية'], ['in', 'استلام من المحطة']], { req: 1 }), R('vehicle_id', 'الآلية', 'vehicles', 'name'), N('liters', 'اللترات', { req: 1 }), T('station', 'المحطة'), N('price_per_liter', 'سعر اللتر')],
    before: async (o) => {
      if (o.direction === 'out') {
        if (!o.vehicle_id) { toast('اختر الآلية'); return false; }
        const { data: v } = await sb.from('vehicles').select('fuel_rate,name').eq('id', o.vehicle_id).single();
        if (v?.fuel_rate && o.liters > v.fuel_rate && !confirm(`⚠ ${v.name}: ${o.liters} لتر أكثر من المعدل (${v.fuel_rate}). تكمل؟`)) return false;
        const { data: b } = await sb.from('fuel_balance').select('balance').maybeSingle();
        if (b && o.liters > b.balance && !confirm(`⚠ رصيد الخزان (${fmt(b.balance)}) أقل من المطلوب. تكمل؟`)) return false;
      }
    },
    buttons: [],
  });
  return async root => { await base(root); const { data } = await sb.from('fuel_balance').select('balance').maybeSingle(); const el = $('#fb b', root); if (el) el.textContent = fmt(data?.balance || 0) + ' لتر'; };
})();

/* ===================== البوابة والأمنية ===================== */
async function mGate(root) {
  let veh = null;
  root.innerHTML = `<div class="card"><h3>البوابة — تسجيل آلية</h3>
    <label>امسح الباركود أو اكتبه</label><div class="row"><input id="code" placeholder="V-XXXXXX" style="flex:1"><button class="btn sec" id="cam">📷</button><button class="btn" id="find">بحث</button></div>
    <div id="info"></div></div><div class="card"><h3>آخر الحركات</h3><div id="log"></div></div>`;
  const log = async () => { const { data } = await sb.from('gate_logs').select('*,vehicles(name)').order('created_at', { ascending: false }).limit(30); $('#log', root).innerHTML = table([['created_at', 'الوقت', fdate], ['event', 'الحركة', v => v === 'exit' ? tag('خروج', 'amb') : tag('دخول')], ['vehicles', 'الآلية', v => esc(v?.name)], ['driver', 'السائق'], ['material', 'المادة'], ['qty', 'الكمية'], ['warning', 'تحذير', v => v ? tag(v, 'red') : '']], data || []); };
  const find = async () => {
    const code = $('#code', root).value.trim(); if (!code) return;
    const { data } = await sb.from('vehicles').select('*').or(`barcode.eq.${code},plate.eq.${code}`).limit(1);
    veh = data?.[0]; if (!veh) { $('#info', root).innerHTML = '<div class="warn">ما لكيت آلية بهذا الرمز</div>'; return; }
    $('#info', root).innerHTML = `<div class="kpi" style="margin:8px 0"><b>${esc(veh.name)}</b><span>${esc(veh.kind || '')} · ${esc(veh.plate || '')} · الحالة: ${veh.status === 'out' ? 'خارج' : 'داخل'}</span></div>
      <label>السائق</label><input id="drv"><label>المادة</label><input id="mat"><label>الكمية</label><input id="qty" type="number" inputmode="decimal">
      <div class="row" style="margin-top:12px"><button class="btn big" id="en" style="flex:1">تسجيل دخول آلية</button><button class="btn big amb" id="ex" style="flex:1">تسجيل خروج آلية</button></div>`;
    const go = ev => async function () {
      this.disabled = true;
      const { data: r, error } = await sb.from('gate_logs').insert({ client_token: uid(), vehicle_id: veh.id, event: ev, driver: $('#drv', root).value, material: $('#mat', root).value, qty: Number($('#qty', root).value) || null }).select().single();
      if (error) { toast('⚠ ' + errMsg(error), 4000); this.disabled = false; return; }
      toast(r.warning ? '⚠ ' + r.warning : 'انسجل'); $('#info', root).innerHTML = r.warning ? `<div class="warn">⚠ ${esc(r.warning)}</div>` : ''; $('#code', root).value = ''; log();
    };
    $('#en', root).onclick = go('enter'); $('#ex', root).onclick = go('exit');
  };
  $('#find', root).onclick = find; $('#code', root).onkeydown = e => { if (e.key === 'Enter') find(); };
  $('#cam', root).onclick = async () => {
    if (!('BarcodeDetector' in window)) return toast('الكاميرا للباركود غير مدعومة بهذا المتصفح — اكتب الرمز');
    const det = new BarcodeDetector(); const st = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
    const m = modal('<video id="v" autoplay playsinline style="width:100%"></video>'); const v = $('#v', m); v.srcObject = st;
    const t = setInterval(async () => { try { const c = await det.detect(v); if (c.length) { clearInterval(t); st.getTracks().forEach(x => x.stop()); m.remove(); $('#code', root).value = c[0].rawValue; find(); } } catch { } }, 400);
    m.addEventListener('click', () => { clearInterval(t); st.getTracks().forEach(x => x.stop()); });
  };
  log();
}
const mExternal = crud({
  title: 'الآليات الخارجية', table: 'external_vehicles', order: 'entered_at',
  cols: [['entered_at', 'الدخول', fdate], ['plate', 'اللوحة'], ['company', 'الجهة'], ['reason', 'السبب'], ['is_supply', 'توريد', v => v ? tag('توريد') : ''], ['banned', 'ممنوعة', v => v ? tag('ممنوعة', 'red') : ''], ['exited_at', 'الخروج', (v, r) => v ? `${fdate(v)} ${r.exit_state === 'loaded' ? tag(r.exit_permit ? 'محمّلة بإذن' : 'محمّلة بدون إذن', r.exit_permit ? '' : 'red') : tag('فارغة')}` : (Date.now() - new Date(r.entered_at) > 144e5 ? tag('باقية > 4 ساعات', 'red') : tag('داخل', 'amb'))]],
  fields: [T('plate', 'رقم اللوحة', { req: 1 }), T('kind', 'نوع السيارة'), T('company', 'الشركة / الجهة'), T('reason', 'سبب الدخول'), T('destination', 'الوجهة'), { k: 'is_supply', label: 'توريد مواد (تظهر شاحنة واصلة للمخزن)', t: 'check' }, P('plate_photo', 'صورة اللوحة')],
  extra: () => `<div class="row"><button class="btn sec" id="aiplate">📷 قراءة اللوحة</button></div>`,
  onReady: m => { $('#aiplate', m).onclick = () => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.capture = 'environment'; i.onchange = async () => { try { const { result: r } = await aiRead('plate', i.files[0]); $('#f_plate', m).value = r.plate || ''; $('#f_kind', m).value = r.kind || ''; const { data } = await sb.from('external_vehicles').select('*').eq('plate', r.plate).order('entered_at', { ascending: false }).limit(1); if (data?.[0]) { $('#f_company', m).value = data[0].company || ''; $('#f_kind', m).value = data[0].kind || r.kind || ''; toast('سيارة معروفة — انعبّت معلوماتها'); } const dt = new DataTransfer(); dt.items.add(i.files[0]); $('#f_plate_photo', m).files = dt.files; } catch (e) { toast(errMsg(e)); } }; i.click(); }; },
  rowBtns: [{ label: 'خروج فارغة', show: r => !r.exited_at, fn: async (r, l) => { if (await run(sb.from('external_vehicles').update({ exited_at: new Date().toISOString(), exit_state: 'empty' }).eq('id', r.id), 'انسجل')) l(); } },
  { label: 'خروج محمّلة', show: r => !r.exited_at, fn: async (r, l) => { const p = confirm('عندها إذن إخراج؟ (موافق = نعم)'); if (await run(sb.from('external_vehicles').update({ exited_at: new Date().toISOString(), exit_state: 'loaded', exit_permit: p }).eq('id', r.id), 'انسجل')) l(); } },
  { label: 'منع', show: r => !r.banned, fn: async (r, l) => { const why = prompt('سبب المنع؟'); if (why === null) return; await sb.from('banned_plates').insert({ plate: r.plate, reason: why }); toast('انضافت للممنوعين'); l(); } }],
  buttons: [{ label: 'ملخص الشركات', fn: rows => { const g = {}; rows.forEach(r => { const k = r.company || '—'; g[k] = (g[k] || 0) + 1; }); modal(`<h3>ملخص لكل شركة</h3>${table([['k', 'الشركة'], ['n', 'عدد الدخلات']], Object.entries(g).map(([k, n]) => ({ k, n })))}`); } }],
});

/* ===================== الحضور والكادر ===================== */
const L = { ar: { title: 'سجل الحضور', day: 'التاريخ', present: 'حاضر', absent: 'غائب', save: 'حفظ', hours: 'الساعات', trade: 'المهنة', no: 'الرقم' }, en: { title: 'Attendance', day: 'Date', present: 'Present', absent: 'Absent', save: 'Save', hours: 'Hours', trade: 'Trade', no: 'No.' }, ku: { title: 'تۆماری ئامادەبوون', day: 'بەروار', present: 'ئامادە', absent: 'غائیب', save: 'پاشەکەوت', hours: 'کاتژمێر', trade: 'پیشە', no: 'ژمارە' } };
let LANG = localStorage.lang || 'ar';
async function mAttendance(root) {
  const t = L[LANG]; const canUp = hasRole([...ADMIN, 'foreman', 'attendance_clerk']);
  const { data: workers } = await sb.from('workers').select('*').eq('active', true).order('name');
  let day = root.dataset.day || today();
  const load = async () => {
    const { data: att } = await sb.from('attendance').select('*').eq('day', day);
    const am = {}; (att || []).forEach(a => am[a.worker_id] = a);
    const groups = {}; (workers || []).forEach(w => (groups[w.nationality || '—'] = groups[w.nationality || '—'] || []).push(w));
    root.innerHTML = `<div class="card"><div class="row"><h3 style="flex:1;margin:0">${t.title}</h3><select id="lg" style="width:auto"><option value="ar">عربي</option><option value="en">English</option><option value="ku">کوردی</option></select></div>
      <div class="row"><label>${t.day}</label><input type="date" id="day" value="${day}" style="width:auto"></div>
      ${canUp ? `<div class="row" style="margin:8px 0"><button class="btn sec" id="fp">⬆ ملف البصمة</button><button class="btn sec" id="fm">📷 ورقة الفورمن</button><button class="btn sec" id="wf">⬆ ملف العمال</button></div>` : ''}
      ${Object.entries(groups).map(([nat, ws]) => { const pres = ws.filter(w => (am[w.id]?.present ?? false)).length; return `<h4>${esc(nat)}</h4>${table([['name', 'الاسم'], ['trade', t.trade], ['number', t.no], ['id', t.present, (v, w) => `<input type="checkbox" data-w="${w.id}" ${am[w.id]?.present ? 'checked' : ''} ${canUp ? '' : 'disabled'}>${am[w.id]?.needs_review ? ' ⚠' : ''}`]], ws)}<div class="mut">${t.present}: ${pres} — ${t.absent}: ${ws.length - pres}</div>`; }).join('')}
      ${canUp ? `<button class="btn" id="sv" style="margin-top:10px">${t.save}</button>` : ''}</div>`;
    $('#lg', root).value = LANG; $('#lg', root).onchange = e => { LANG = localStorage.lang = e.target.value; mAttendance(root); };
    $('#day', root).onchange = e => { day = root.dataset.day = e.target.value; load(); };
    const sv = $('#sv', root);
    if (sv) sv.onclick = async () => {
      const rows = [...root.querySelectorAll('[data-w]')].map(c => ({ worker_id: c.dataset.w, day, present: c.checked, source: 'manual', recorded_by: ME.id, site_id: ME.site_id }));
      if (await run(sb.from('attendance').upsert(rows, { onConflict: 'worker_id,day' }), 'انحفظ الحضور')) load();
    };
    const pickFile = (accept, fn) => { const i = document.createElement('input'); i.type = 'file'; i.accept = accept; i.onchange = () => fn(i.files[0]); i.click(); };
    if ($('#fp', root)) $('#fp', root).onclick = () => pickFile('.xlsx,.xls,.csv', async f => {
      const wbk = XLSX.read(await f.arrayBuffer());
      const rows = XLSX.utils.sheet_to_json(wbk.Sheets[wbk.SheetNames[0]], { header: 1 });
      const found = new Map(), un = [];
      for (const r of rows.slice(1)) {
        const nm = r.find(c => typeof c === 'string' && /[^\d\s:\-\/]/.test(c)); const fid = r.find(c => typeof c === 'number' || /^\d+$/.test(String(c)));
        if (!nm) continue;
        let best = null, sc = 0; (workers || []).forEach(w => { const s = nameScore(nm, w.name); if (s > sc) { sc = s; best = w; } });
        const wk = (workers || []).find(w => fid && w.fingerprint_id == fid) || (sc >= 0.5 ? best : null);
        if (wk) { found.set(wk.id, fid); } else un.push(nm);
      }
      const rowsA = [...found.keys()].map(id => ({ worker_id: id, day, present: true, source: 'fingerprint', site_id: ME.site_id, recorded_by: ME.id }));
      if (rowsA.length) await run(sb.from('attendance').upsert(rowsA, { onConflict: 'worker_id,day' }));
      for (const [id, fid] of found) if (fid) await sb.from('workers').update({ fingerprint_id: String(fid) }).eq('id', id);
      toast(`تطابق ${found.size} — غير متطابق ${un.length}`, 5000); if (un.length) modal(`<h3>أسماء ما تطابقت</h3><div>${un.map(esc).join('<br>')}</div>`); load();
    });
    if ($('#fm', root)) $('#fm', root).onclick = () => pickFile('image/*', async f => {
      toast('جاري قراءة الورقة مرتين للتدقيق...', 8000);
      try {
        const { result, second, agree } = await aiRead('attendance_sheet', f, true);
        const photo = await upload(f); const rows = [], dbl = [];
        (result.rows || []).forEach((r, i) => {
          let best = null, sc = 0; (workers || []).forEach(w => { const s = nameScore(r.name, w.name); if (s > sc) { sc = s; best = w; } });
          const other = second?.rows?.[i]; const mismatch = !other || other.absent !== r.absent;
          if (best && sc >= 0.5) rows.push({ worker_id: best.id, day, present: !r.absent, source: 'foreman_sheet', needs_review: mismatch || sc < 0.8, site_id: ME.site_id, recorded_by: ME.id }); else dbl.push(r.name);
        });
        if (rows.length) await run(sb.from('attendance').upsert(rows, { onConflict: 'worker_id,day' }), `انسجل ${rows.length}${agree ? '' : ' (فيه فروق بين القراءتين — علّمتها ⚠)'}`);
        await sb.from('notifications').insert({ site_id: ME.site_id, title: 'ورقة فورمن تحتاج تثبيت', body: photo, kind: 'attendance' });
        if (dbl.length) modal(`<h3>مشكوك بيهم</h3>${dbl.map(esc).join('<br>')}`); load();
      } catch (e) { toast('⚠ ' + errMsg(e), 5000); }
    });
    if ($('#wf', root)) $('#wf', root).onclick = () => pickFile('.xlsx,.xls,.csv', async f => {
      const wb = XLSX.read(await f.arrayBuffer()); const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
      let upd = 0, add = 0;
      for (const r of rows) {
        const name = r['الاسم'] || r.name || r.Name; if (!name) continue;
        const rec = { name: String(name).trim(), nationality: r['الجنسية'] || r.nationality || 'عراقي', trade: r['المهنة'] || r.trade, number: r['الرقم'] ? String(r['الرقم']) : null, daily_wage: Number(r['الأجر'] || r.wage) || 0 };
        let best = null, sc = 0; (workers || []).forEach(w => { const s = nameScore(rec.name, w.name); if (s > sc) { sc = s; best = w; } });
        if (best && sc >= 0.85) { await sb.from('workers').update(rec).eq('id', best.id); upd++; } else { await sb.from('workers').insert({ ...rec, client_token: uid() }); add++; }
      }
      toast(`حُدّث ${upd} — أضيف ${add}`); mAttendance(root);
    });
  };
  await load();
}
const mWorkers = crud({
  title: 'العمال والكادر', table: 'workers', order: 'name',
  cols: [['name', 'الاسم'], ['nationality', 'الجنسية'], ['trade', 'المهنة'], ['number', 'الرقم'], ['daily_wage', 'الأجر اليومي', fmt], ['contractor', 'المقاول'], ['active', 'فعّال', v => v ? '✓' : '✗']],
  fields: [T('name', 'الاسم', { req: 1 }), T('nationality', 'الجنسية', { def: 'عراقي' }), T('trade', 'المهنة'), T('number', 'الرقم'), N('daily_wage', 'الأجر اليومي'), T('contractor', 'المقاول'), { k: 'active', label: 'فعّال', t: 'check', def: true }],
});
const mPayroll = crud({
  title: 'الرواتب والسلف والخصومات', table: 'payroll_items', select: '*,workers(name)',
  cols: [['created_at', 'التاريخ', fdate], ['workers', 'العامل', v => esc(v?.name)], ['kind', 'النوع', v => ({ salary: 'راتب', deduction: 'خصم', advance: 'سلفة', cut: 'قطع راتب' }[v])], ['amount', 'المبلغ', fmt], ['period', 'الفترة'], ['posted', 'مرحّل', v => v ? tag('مرحّل') : tag('لا', 'amb')], ['notes', 'ملاحظات']],
  fields: [R('worker_id', 'العامل', 'workers', 'name', { req: 1 }), S('kind', 'النوع', [['salary', 'راتب'], ['deduction', 'خصم'], ['advance', 'سلفة'], ['cut', 'قطع راتب']], { req: 1 }), N('amount', 'المبلغ', { req: 1 }), T('period', 'الفترة (مثال 2026-11)'), A('notes', 'ملاحظات')],
  buttons: [{ label: '💰 احتساب الأجور اليومية للفترة', fn: async () => { const per = prompt('الفترة (مثال 2026-11):', today().slice(0, 7)); if (!per) return; const { data: ws } = await sb.from('workers').select('*').eq('active', true); const { data: at } = await sb.from('attendance').select('*').gte('day', per + '-01').lte('day', per + '-31').eq('present', true); const rows = (ws || []).map(w => { const days = (at || []).filter(a => a.worker_id === w.id); const hrs = days.reduce((s, a) => s + Number(a.hours || 8), 0); return { client_token: `sal-${per}-${w.id}`, worker_id: w.id, kind: 'salary', amount: Math.round(Number(w.daily_wage || 0) * hrs / 8), period: per, notes: `${days.length} يوم / ${hrs} ساعة` }; }).filter(r => r.amount > 0); if (await run(sb.from('payroll_items').upsert(rows, { onConflict: 'client_token', ignoreDuplicates: true }), 'انحسبت ' + rows.length)) mount(); } },
  { label: '⇨ ترحيل للصندوق', fn: async (rows) => { const pend = rows.filter(r => r.kind === 'salary' && !r.posted); const tot = pend.reduce((a, r) => a + Number(r.amount), 0); if (!pend.length || !confirm(`ترحيل ${fmt(tot)} د.ع للصندوق؟`)) return; const ok = await run(sb.from('cash_ledger').insert({ direction: 'out', category: 'رواتب', amount: tot, client_token: 'pay-' + uid(), notes: `${pend.length} راتب` })); if (ok) { await sb.from('payroll_items').update({ posted: true }).in('id', pend.map(r => r.id)); toast('رُحّلت'); mount(); } } }],
});

/* ===================== الحسابات ===================== */
async function mCash(root) {
  const { data } = await sb.from('cash_ledger').select('*').neq('ref', 'legacy').eq('box', 'main').order('created_at', { ascending: false }).limit(500);
  const rows = data || []; const bal = rows.reduce((a, r) => a + (r.direction === 'in' ? 1 : -1) * Number(r.amount), 0);
  const tin = rows.filter(r => r.day === today() && r.direction === 'in').reduce((a, r) => a + Number(r.amount), 0), tout = rows.filter(r => r.day === today() && r.direction === 'out').reduce((a, r) => a + Number(r.amount), 0);
  const cats = {}; rows.filter(r => r.day.slice(0, 7) === today().slice(0, 7)).forEach(r => { const k = r.category || '—'; cats[k] = cats[k] || { i: 0, o: 0 }; cats[k][r.direction === 'in' ? 'i' : 'o'] += Number(r.amount); });
  root.innerHTML = `<div class="grid"><div class="kpi"><span>رصيد الصندوق الرئيسي</span><b>${fmt(bal)}</b></div><div class="kpi"><span>وارد اليوم</span><b>${fmt(tin)}</b></div><div class="kpi"><span>صادر اليوم</span><b>${fmt(tout)}</b></div></div>
  <div class="card"><div class="row"><h3 style="flex:1;margin:0">الدفتر</h3><button class="btn" id="in">+ وارد</button><button class="btn amb" id="out">+ صادر</button></div>
  <div class="row" style="margin:8px 0"><button class="btn sec" id="cl">إغلاق الصندوق اليومي</button><button class="btn sec" id="ex">⬇ Excel</button><button class="btn sec" id="im">⬆ استيراد النظام القديم</button><button class="btn sec" id="cu">تحويل دولار</button><button class="btn sec" id="cd">تسليم عهدة صرف</button><button class="btn sec" id="op">رصيد افتتاحي</button></div>
  ${table([['day', 'التاريخ'], ['direction', 'الحركة', v => v === 'in' ? tag('وارد') : tag('صادر', 'amb')], ['category', 'الفئة'], ['amount', 'المبلغ', fmt], ['notes', 'ملاحظات']], rows.slice(0, 100), r => r.reverses || r.ref === 'reversed' ? tag('عكس') : `<button class="btn sec" data-rv="${r.id}">عكس</button>`)}</div>
  <div class="card"><h3>الملخص الشهري</h3>${table([['k', 'الفئة'], ['i', 'وارد', fmt], ['o', 'صادر', fmt]], Object.entries(cats).map(([k, v]) => ({ k, ...v })))}</div>`;
  const add = dir => openForm({ title: dir === 'in' ? 'وارد' : 'صادر', fields: [D('day', 'التاريخ', { def: today() }), T('category', 'الفئة', { req: 1 }), N('amount', 'المبلغ', { req: 1 }), A('notes', 'ملاحظات')], save: async o => { o.direction = dir; o.box = 'main'; if (!(await run(sb.from('cash_ledger').insert(o), 'انسجل'))) return false; mCash(root); } });
  $('#in', root).onclick = () => add('in'); $('#out', root).onclick = () => add('out');
  $('#op', root).onclick = () => openForm({ title: 'رصيد افتتاحي', fields: [D('day', 'التاريخ', { def: today() }), N('amount', 'المبلغ', { req: 1 })], save: async o => { Object.assign(o, { direction: 'in', category: 'رصيد افتتاحي', box: 'main' }); if (!(await run(sb.from('cash_ledger').insert(o), 'انسجل'))) return false; mCash(root); } });
  root.querySelectorAll('[data-rv]').forEach(b => b.onclick = async () => { const r = rows.find(x => x.id === b.dataset.rv); if (!confirm('سوّي حركة عكس لهذي الحركة؟')) return; if (await run(sb.from('cash_ledger').insert({ direction: r.direction === 'in' ? 'out' : 'in', category: 'عكس: ' + (r.category || ''), amount: r.amount, reverses: r.id, box: r.box, client_token: 'rv-' + r.id, notes: 'تصحيح' }), 'انعكست')) mCash(root); });
  $('#cl', root).onclick = async () => { if (await run(sb.from('cash_closings').insert({ day: today(), total_in: tin, total_out: tout, balance: bal }), 'أُغلق الصندوق')) { } };
  $('#ex', root).onclick = () => { const ws = XLSX.utils.json_to_sheet(rows.map(r => ({ التاريخ: r.day, الحركة: r.direction === 'in' ? 'وارد' : 'صادر', الفئة: r.category, المبلغ: r.amount, ملاحظات: r.notes }))); const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, 'الدفتر'); XLSX.writeFile(wb, `الدفتر-${today()}.xlsx`); };
  $('#im', root).onclick = () => { const i = document.createElement('input'); i.type = 'file'; i.accept = '.xlsx,.xls,.csv'; i.onchange = async () => { const wb = XLSX.read(await i.files[0].arrayBuffer()); const js = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]); const out = js.map((r, k) => ({ client_token: 'leg-' + Date.now() + '-' + k, day: String(r['التاريخ'] || today()).slice(0, 10), direction: (r['الحركة'] || '').includes('صادر') ? 'out' : 'in', category: r['الفئة'], amount: Number(r['المبلغ']) || 0, notes: r['ملاحظات'], ref: 'legacy' })).filter(r => r.amount); if (await run(sb.from('cash_ledger').insert(out), `استُوردت ${out.length} حركة (ما تدخل بالرصيد)`)) mCash(root); }; i.click(); };
  $('#cu', root).onclick = () => openForm({ title: 'تحويل دولار', fields: [N('usd', 'المبلغ بالدولار', { req: 1 }), N('rate', 'سعر الصرف (دينار لكل $)', { req: 1 })], save: async o => { const id = uid(); const a = await run(sb.from('cash_ledger').insert({ direction: 'out', category: 'تحويل إلى دولار', amount: o.usd * o.rate, box: 'main', client_token: 'fx-o-' + id })); const b = await run(sb.from('cash_ledger').insert({ direction: 'in', category: 'تحويل من دينار', amount: o.usd, currency: 'USD', box: 'usd', client_token: 'fx-i-' + id, notes: 'سعر ' + o.rate })); if (!a || !b) return false; mCash(root); } });
  $('#cd', root).onclick = async () => { const { data: us } = await sb.from('profiles').select('id,full_name').eq('role', 'disbursement').eq('approved', true); openForm({ title: 'تسليم عهدة لمسؤولة الصرف', fields: [S('u', 'المستلمة', (us || []).map(u => [u.id, u.full_name]), { req: 1 }), N('amount', 'المبلغ', { req: 1 })], save: async o => { const id = uid(); const a = await run(sb.from('cash_ledger').insert({ direction: 'out', category: 'عهدة صرف', amount: o.amount, box: 'main', client_token: 'cd-o-' + id })); const b = await run(sb.from('cash_ledger').insert({ direction: 'in', category: 'عهدة مستلمة', amount: o.amount, box: 'disbursement:' + o.u, client_token: 'cd-i-' + id })); if (!a || !b) return false; mCash(root); } }); };
}
async function mDisb(root) {
  const box = 'disbursement:' + ME.id;
  const { data } = await sb.from('cash_ledger').select('*').eq('box', box).order('created_at', { ascending: false });
  const bal = (data || []).reduce((a, r) => a + (r.direction === 'in' ? 1 : -1) * Number(r.amount), 0);
  root.innerHTML = `<div class="kpi"><span>رصيد صندوق الصرف</span><b>${fmt(bal)}</b></div><div class="card"><div class="row"><h3 style="flex:1;margin:0">صندوق الصرف</h3><button class="btn amb" id="o">+ صرف</button></div>${table([['created_at', 'الوقت', fdate], ['direction', 'الحركة', v => v === 'in' ? tag('عهدة') : tag('صرف', 'amb')], ['category', 'البند'], ['amount', 'المبلغ', fmt], ['notes', 'ملاحظات']], data || [])}</div>`;
  $('#o', root).onclick = () => openForm({ title: 'صرف', fields: [T('category', 'البند', { req: 1 }), N('amount', 'المبلغ', { req: 1 }), A('notes', 'ملاحظات')], save: async o => { if (o.amount > bal) { toast('⚠ أكثر من الرصيد'); return false; } o.direction = 'out'; o.box = box; if (!(await run(sb.from('cash_ledger').insert(o), 'انسجل'))) return false; mDisb(root); } });
}
const mAdvances = crud({
  title: 'السلف التشغيلية', table: 'advances',
  cols: [['party_kind', 'النوع'], ['party', 'الجهة'], ['amount', 'المبلغ', fmt], ['settled', 'المُسوّى', fmt], ['amount', 'المتبقي', (v, r) => tag(fmt(r.amount - r.settled), r.amount - r.settled > 0 ? 'amb' : '')], ['notes', 'ملاحظات']],
  fields: [S('party_kind', 'النوع', [['معمل', 'معمل'], ['معمل سمنت', 'معمل سمنت'], ['ناقل', 'ناقل'], ['شخص', 'شخص'], ['محطة', 'محطة']], { req: 1 }), T('party', 'الاسم', { req: 1 }), N('amount', 'المبلغ', { req: 1 }), A('notes', 'ملاحظات (السلفة مو مصروف — تُسوّى بالفواتير أو الإرجاع)')],
  rowBtns: [{ label: 'تسوية', fn: async (r, l) => { const v = Number(prompt('مبلغ التسوية (فواتير معتمدة / إرجاع):')); if (v > 0 && await run(sb.from('advances').update({ settled: Number(r.settled) + v }).eq('id', r.id), 'تمت')) l(); } }],
});
const mContractorPay = crud({ title: 'حسابات المقاولين (الدفعات)', table: 'contractor_payments', cols: [['created_at', 'التاريخ', fdate], ['contractor', 'المقاول'], ['amount', 'المبلغ', fmt], ['notes', 'ملاحظات']], fields: [T('contractor', 'المقاول', { req: 1 }), N('amount', 'الدفعة', { req: 1 }), A('notes', 'ملاحظات')] });
async function mStation(root) {
  const { data } = await sb.from('fuel_station_statements').select('*').order('created_at', { ascending: false });
  root.innerHTML = `<div class="card"><div class="row"><h3 style="flex:1;margin:0">سلفة الكاز — محطة الفلوجة</h3><button class="btn" id="up">⬆ رفع كشف المحطة</button></div>${table([['created_at', 'التاريخ', fdate], ['period', 'الفترة'], ['liters', 'اللترات', fmt], ['price_per_liter', 'سعر اللتر', fmt], ['amount', 'المبلغ', fmt], ['status', 'الحالة', v => tag(v === 'approved' ? 'معتمد' : 'للمراجعة', v === 'approved' ? '' : 'amb')], ['photo', 'الكشف', link]], data || [], r => (r.status !== 'approved' ? `<button class="btn sec" data-m="${r.id}">مطابقة</button> ` : '') + (r.status !== 'approved' && hasRole(['accounts_head']) ? `<button class="btn" data-ap="${r.id}">اعتماد</button>` : ''))}</div>`;
  $('#up', root).onclick = () => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*,application/pdf'; i.onchange = async () => { toast('جاري قراءة الكشف مرتين...', 8000); try { const { result: r, agree } = await aiRead('station_statement', i.files[0], true); const photo = await upload(i.files[0]); const lines = r.lines || []; const sum = lines.reduce((a, l) => a + Number(l.liters || 0), 0); const warn = []; if (!agree) warn.push('القراءتان مختلفتان'); if (r.liters && Math.abs(sum - r.liters) > 0.5) warn.push(`مجموع الأسطر ${fmt(sum)} ≠ المجموع ${fmt(r.liters)}`); const seen = new Set(), dup = []; lines.forEach(l => { const k = `${l.date}|${l.liters}|${l.vehicle}`; if (seen.has(k)) dup.push(k); seen.add(k); }); if (dup.length) warn.push(`${dup.length} سطر مكرر`); if (await run(sb.from('fuel_station_statements').insert({ client_token: uid(), period: r.period, liters: r.liters, amount: r.amount, price_per_liter: r.price_per_liter, lines, photo }), 'انرفع الكشف')) { if (warn.length) modal(`<h3>⚠ ملاحظات التدقيق</h3>${warn.map(w => `<div class="warn">${esc(w)}</div>`).join('')}`); mStation(root); } } catch (e) { toast('⚠ ' + errMsg(e), 5000); } }; i.click(); };
  root.querySelectorAll('[data-m]').forEach(b => b.onclick = async () => { const st = data.find(x => x.id === b.dataset.m); const { data: logs } = await sb.from('fuel_logs').select('liters').eq('direction', 'in'); const rec = (logs || []).reduce((a, x) => a + Number(x.liters), 0); modal(`<h3>مطابقة</h3><p>لترات الكشف: <b>${fmt(st.liters)}</b></p><p>مجموع استلامات الكاز المسجّلة: <b>${fmt(rec)}</b></p><p>الفرق: <b>${fmt(st.liters - rec)}</b></p><div class="mut">مسؤولين الكاز يأكدون كل سطر من قائمة الأسطر.</div>${table([['date', 'التاريخ'], ['vehicle', 'الآلية'], ['liters', 'لتر'], ['amount', 'مبلغ']], st.lines || [])}`); });
  root.querySelectorAll('[data-ap]').forEach(b => b.onclick = async () => { const st = data.find(x => x.id === b.dataset.ap); if (!confirm('اعتماد وخصم من السلفة؟')) return; if (await run(sb.from('fuel_station_statements').update({ status: 'approved' }).eq('id', st.id))) { const { data: adv } = await sb.from('advances').select('*').eq('party', 'محطة الفلوجة').limit(1); if (adv?.[0]) await sb.from('advances').update({ settled: Number(adv[0].settled) + Number(st.amount || 0) }).eq('id', adv[0].id); else toast('ما لكيت سلفة باسم «محطة الفلوجة» — أضفها بالسلف'); mStation(root); } });
}

/* ===================== المبيعات ===================== */
const mApartments = crud({
  title: 'الشقق', table: 'apartments', order: 'building',
  cols: [['building', 'البناية'], ['floor', 'الطابق'], ['number', 'الشقة'], ['area', 'المساحة م²'], ['status', 'الحالة', v => ({ free: tag('متاحة'), reserved: tag('محجوزة', 'amb'), sold: tag('مباعة', 'red') }[v])]],
  fields: [S('building', 'البناية', BUILDINGS, { req: 1 }), N('floor', 'الطابق', { req: 1 }), T('number', 'رقم الشقة', { req: 1 }), N('area', 'المساحة م²', { req: 1 }), S('status', 'الحالة', [['free', 'متاحة'], ['reserved', 'محجوزة'], ['sold', 'مباعة']], { req: 1 })],
  top: () => '<div class="mut">T1 إلى T4 حصة المستثمر</div>', addRoles: ['sales_head'],
});
const mCustomers = crud({
  title: 'الزبائن والمستأجرين', table: 'customers', order: 'name',
  cols: [['name', 'الاسم'], ['phone', 'الهاتف'], ['kind', 'النوع', v => v === 'tenant' ? 'مستأجر' : 'مشتري'], ['id_doc', 'المستمسك']],
  fields: [T('name', 'الاسم', { req: 1 }), T('phone', 'الهاتف'), S('kind', 'النوع', [['buyer', 'مشتري'], ['tenant', 'مستأجر']], { req: 1 }), T('id_doc', 'رقم المستمسك'), A('notes', 'ملاحظات')],
  rowBtns: [{ label: 'ملف / عقد', fn: async (r) => { const { data } = await sb.from('contract_files').select('*').eq('customer_id', r.id); const m = modal(`<h3>ملف ${esc(r.name)}</h3>${table([['title', 'المستند'], ['file_url', 'الملف', link]], data || [])}<button class="btn" id="cf">+ رفع مستند</button>`); $('#cf', m).onclick = () => { m.remove(); openForm({ title: 'مستند', fields: [T('title', 'العنوان (عقد، هوية…)', { req: 1 }), P('file_url', 'الملف')], save: async o => { o.customer_id = r.id; return (await run(sb.from('contract_files').insert(o), 'انرفع')) ? true : false; } }); }; } }],
});
function planOf(b) {
  const total = Number(b.total || 0), rem = Math.max(0, total - Number(b.down_payment || 0) - Number(b.handover_payment || 0));
  const cap = Number(b.down_payment) < 90000000 ? 90 : 84; let inst = Number(b.installment || 2000000), months = Math.ceil(rem / inst);
  if (months > cap) { months = cap; inst = Math.ceil(rem / cap); }
  return { total, rem, inst, months };
}
async function mBookings(root) {
  const { data } = await sb.from('bookings').select('*,customers(name,phone),apartments(building,floor,number)').order('created_at', { ascending: false });
  const { data: pays } = await sb.from('sales_payments').select('*');
  const paidBy = {}; (pays || []).forEach(p => paidBy[p.booking_id] = (paidBy[p.booking_id] || 0) + Number(p.amount));
  const sched = b => {
    const pl = planOf(b), rows = []; const st = new Date(b.start_date), day = b.due_day || st.getDate();
    rows.push({ k: 'مقدّمة', due: b.start_date, amt: Number(b.down_payment) }); if (Number(b.handover_payment)) rows.push({ k: 'دفعة استلام', due: null, amt: Number(b.handover_payment) });
    for (let i = 1; i <= pl.months; i++) { const d = new Date(st.getFullYear(), st.getMonth() + i, 1); d.setDate(Math.min(day, new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate())); rows.push({ k: 'قسط ' + i, due: d.toISOString().slice(0, 10), amt: i === pl.months ? pl.rem - pl.inst * (pl.months - 1) : pl.inst }); }
    let paid = paidBy[b.id] || 0; rows.forEach(r => { const x = Math.min(paid, r.amt); r.paid = x; paid -= x; r.late = r.due && r.due < today() && r.paid < r.amt; }); return rows;
  };
  const late = b => sched(b).filter(r => r.late).reduce((a, r) => a + r.amt - r.paid, 0);
  const canEdit = hasRole(['sales_head', 'gm1', 'gm2']);
  root.innerHTML = `<div class="card"><div class="row"><h3 style="flex:1;margin:0">الحجوزات والأقساط</h3>${canEdit ? '<button class="btn" id="nb">+ حجز جديد</button>' : ''}</div><input id="q" placeholder="بحث بالاسم أو الرقم أو الشقة" style="margin:8px 0"><div id="tb"></div></div>`;
  const paint = () => { const q = norm($('#q', root).value); const f = (data || []).filter(b => !q || norm(`${b.customers?.name} ${b.customers?.phone} ${b.apartments?.building} ${b.apartments?.number}`).includes(q)); $('#tb', root).innerHTML = table([['customers', 'الزبون', v => esc(v?.name)], ['apartments', 'الشقة', v => esc(`${v?.building}-${v?.floor}-${v?.number}`)], ['total', 'السعر', fmt], ['id', 'المدفوع', v => fmt(paidBy[v] || 0)], ['id', 'المتبقي', (v, b) => fmt(b.total - (paidBy[v] || 0))], ['id', 'المتأخر', (v, b) => { const l = late(b); return l ? tag(fmt(l), 'red') : '—'; }]], f, b => `<button class="btn sec" data-o="${b.id}">فتح</button>`); root.querySelectorAll('[data-o]').forEach(x => x.onclick = () => open(data.find(b => b.id === x.dataset.o))); };
  $('#q', root).oninput = paint; paint();
  const open = b => {
    const s = sched(b), paid = paidBy[b.id] || 0, lt = late(b);
    const msg = encodeURIComponent(`السيد ${b.customers?.name}\nتذكير: عندكم مبلغ متأخر ${fmt(lt)} دينار على الشقة ${b.apartments?.building}-${b.apartments?.number}. نرجو التسديد. شركة المنصور`);
    const m = modal(`<h3>${esc(b.customers?.name)} — ${esc(b.apartments?.building)}-${esc(b.apartments?.number)}</h3><div class="grid"><div class="kpi"><span>السعر</span><b>${fmt(b.total)}</b></div><div class="kpi"><span>المدفوع</span><b>${fmt(paid)}</b></div><div class="kpi"><span>المتبقي</span><b>${fmt(b.total - paid)}</b></div><div class="kpi"><span>المتأخر</span><b>${fmt(lt)}</b></div></div>
      <div class="row" style="margin:8px 0"><button class="btn" id="pp">+ تسجيل دفعة</button>${lt ? `<a class="btn amb" target="_blank" href="https://wa.me/${phoneWA(b.customers?.phone)}?text=${msg}">تذكير واتساب</a>` : ''}<button class="btn sec" id="ks">كشف حساب</button></div>
      <div class="tw" style="max-height:40vh;overflow:auto">${table([['k', 'الدفعة'], ['due', 'الاستحقاق'], ['amt', 'المبلغ', fmt], ['paid', 'المدفوع', fmt], ['late', '', v => v ? tag('متأخر', 'red') : '']], s)}</div>`);
    $('#ks', m).onclick = () => { const w = window.open('', '_blank'); w.document.write(`<html dir="rtl"><body style="font-family:sans-serif"><h2>كشف حساب — ${esc(b.customers?.name)}</h2><p>الشقة ${esc(b.apartments?.building)}-${esc(b.apartments?.number)} | السعر ${fmt(b.total)} | المدفوع ${fmt(paid)} | المتبقي ${fmt(b.total - paid)}</p>${table([['k', 'الدفعة'], ['due', 'الاستحقاق'], ['amt', 'المبلغ', fmt], ['paid', 'المدفوع', fmt]], s)}</body></html>`); setTimeout(() => w.print(), 400); };
    $('#pp', m).onclick = () => { m.remove(); openForm({ title: 'تسجيل دفعة', fields: [N('amount', 'المبلغ', { req: 1 }), S('kind', 'النوع', [['installment', 'قسط'], ['down', 'مقدّمة'], ['handover', 'دفعة استلام']], { req: 1 }), N('services', 'خدمات (صيانة/كهرباء/إنترنت/ماء) بنفس الوصل', { def: 0 }), D('day', 'التاريخ', { def: today() })], save: async o => { o.booking_id = b.id; if (!(await run(sb.from('sales_payments').insert(o), 'انسجلت'))) return false; const after = (paidBy[b.id] || 0) + o.amount; const wm = encodeURIComponent(`وصل استلام — شركة المنصور\nالسيد ${b.customers?.name}\nالمبلغ: ${fmt(o.amount)}${o.services ? ' + خدمات ' + fmt(o.services) : ''}\nالمدفوع الكلي: ${fmt(after)}\nالمتبقي: ${fmt(b.total - after)}`); if (b.customers?.phone) window.open(`https://wa.me/${phoneWA(b.customers.phone)}?text=${wm}`, '_blank'); mBookings(root); } }); };
  };
  const nb = $('#nb', root);
  if (nb) nb.onclick = async () => {
    const apts = (await sb.from('apartments').select('*').neq('status', 'sold').order('building')).data || [];
    const custs = await refOpts('customers', 'name');
    const bs = [...new Set(apts.map(a => a.building))];
    const m = modal(`<h3>حجز جديد</h3>
      <label>الزبون</label><select id="c"><option value="">—</option>${custs.map(([a, b]) => `<option value="${a}">${esc(b)}</option>`).join('')}</select>
      <label>البناية</label><select id="b"><option value="">—</option>${bs.map(x => `<option>${esc(x)}</option>`).join('')}</select>
      <label>الطابق</label><select id="f"></select><label>الشقة</label><select id="a"></select>
      <div class="grid"><div><label>المساحة م²</label><input id="ar" type="number"></div><div><label>سعر المتر</label><input id="mp" type="number" value="1750000"></div></div>
      <div class="grid"><div><label>نوع الخصم</label><select id="dk"><option value="amt">مبلغ</option><option value="pct">نسبة %</option><option value="mtr">على سعر المتر</option></select></div><div><label>قيمة الخصم</label><input id="dv" type="number" value="0"></div></div>
      <label>سبب الخصم</label><input id="dr">
      <div class="grid"><div><label>المقدّمة</label><input id="dp" type="number" value="90000000"></div><div><label>دفعة الاستلام</label><input id="hp" type="number" value="50000000"></div><div><label>القسط الشهري</label><input id="in" type="number" value="2000000"></div></div>
      <label>تاريخ البداية</label><input id="sd" type="date" value="${today()}">
      <div class="kpi" style="margin-top:10px" id="pv"></div>
      <div class="row" style="margin-top:12px"><button class="btn" id="sv">حفظ الحجز</button></div>`);
    const g = id => $('#' + id, m).value;
    const calc = () => {
      const area = Number(g('ar')) || 0; let mp = Number(g('mp')), disc = 0, dv = Number(g('dv')) || 0;
      if (g('dk') === 'mtr') mp = Math.max(0, mp - dv); let total = area * mp; if (g('dk') === 'amt') disc = dv; if (g('dk') === 'pct') disc = total * dv / 100; if (g('dk') === 'mtr') disc = area * dv; total -= (g('dk') === 'mtr' ? 0 : disc);
      const o = { total, down_payment: Number(g('dp')), handover_payment: Number(g('hp')), installment: Number(g('in')) }; const p = planOf(o);
      $('#pv', m).innerHTML = `<span>الإجمالي بعد الخصم</span><b>${fmt(total)}</b><span>المتبقي بعد المقدّمة والاستلام: ${fmt(p.rem)} ← ${p.months} قسط × ${fmt(p.inst)}</span>`; return { ...o, disc, mp };
    };
    $('#b', m).onchange = () => { const fl = [...new Set(apts.filter(a => a.building === g('b')).map(a => a.floor))]; $('#f', m).innerHTML = '<option value="">—</option>' + fl.map(x => `<option>${x}</option>`).join(''); $('#a', m).innerHTML = ''; };
    $('#f', m).onchange = () => { $('#a', m).innerHTML = '<option value="">—</option>' + apts.filter(a => a.building === g('b') && String(a.floor) === g('f')).map(a => `<option value="${a.id}" data-ar="${a.area}">شقة ${esc(a.number)} (${a.area} م²)</option>`).join(''); };
    $('#a', m).onchange = () => { $('#ar', m).value = $('#a', m).selectedOptions[0]?.dataset.ar || ''; calc(); };
    m.querySelectorAll('input,select').forEach(e => e.addEventListener('input', calc)); calc();
    const token = uid();
    $('#sv', m).onclick = async function () {
      if (!g('c') || !g('a')) return toast('اختر الزبون والشقة'); this.disabled = true;
      const c = calc(), p = planOf(c);
      const ok = await run(sb.from('bookings').insert({ client_token: token, customer_id: g('c'), apartment_id: g('a'), area: Number(g('ar')), meter_price: c.mp, discount: c.disc, discount_reason: g('dr'), total: c.total, down_payment: c.down_payment, handover_payment: c.handover_payment, installment: p.inst, months: p.months, start_date: g('sd'), due_day: new Date(g('sd')).getDate() }), 'انحفظ الحجز');
      if (ok) { await sb.from('apartments').update({ status: 'reserved' }).eq('id', g('a')); m.remove(); mBookings(root); } else this.disabled = false;
    };
  };
}

/* ===================== المستخدمين ===================== */
async function mUsers(root) {
  const { data } = await sb.from('profiles').select('*').order('approved').order('created_at', { ascending: false });
  const { data: sites } = await sb.from('sites').select('*'); SITES = sites || [];
  const roleOpts = Object.entries(ROLES).filter(([k]) => k !== 'pending' && (isOwner() || !['owner', 'developer'].includes(k)));
  root.innerHTML = `<div class="card"><div class="row"><h3 style="flex:1;margin:0">المستخدمين والموافقات</h3><button class="btn sec" id="bc">🖨 باركودات الكادر</button></div>${table([['full_name', 'الاسم'], ['username', 'المستخدم'], ['phone', 'الهاتف'], ['role', 'الصفة', (v, r) => `<select data-r="${r.id}">${roleOpts.concat(r.role === 'pending' ? [['pending', 'بانتظار الموافقة']] : []).map(([k, l]) => `<option value="${k}" ${k === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`], ['site_id', 'الموقع', (v, r) => isOwner() ? `<select data-s="${r.id}">${SITES.map(s => `<option value="${s.id}" ${s.id === v ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>` : esc(SITES.find(s => s.id === v)?.name)], ['approved', 'الحالة', v => v ? tag('مفعّل') : tag('ينتظر', 'amb')], ['login_number', 'رقم الدخول'], ['barcode', 'الباركود']], data || [], r => (r.approved ? `<button class="btn sec" data-x="${r.id}">إيقاف</button>` : `<button class="btn" data-ok="${r.id}">موافقة</button>`) + (isOwner() ? ` <button class="btn red" data-del="${r.id}">حذف</button>` : ''))}</div>`;
  root.querySelectorAll('[data-r]').forEach(s => s.onchange = async () => { const ok = await run(sb.from('profiles').update({ role: s.value }).eq('id', s.dataset.r), 'تغيّرت الصفة'); if (!ok) mUsers(root); });
  root.querySelectorAll('[data-s]').forEach(s => s.onchange = () => run(sb.from('profiles').update({ site_id: Number(s.value) }).eq('id', s.dataset.s), 'تغيّر الموقع'));
  root.querySelectorAll('[data-ok]').forEach(b => b.onclick = async () => { const u = data.find(x => x.id === b.dataset.ok); const role = root.querySelector(`[data-r="${u.id}"]`).value; if (role === 'pending') return toast('اختر الصفة أولاً'); if (await run(sb.from('profiles').update({ approved: true, role }).eq('id', u.id), 'تمت الموافقة')) mUsers(root); });
  root.querySelectorAll('[data-x]').forEach(b => b.onclick = async () => { if (await run(sb.from('profiles').update({ approved: false }).eq('id', b.dataset.x), 'أُوقف')) mUsers(root); });
  root.querySelectorAll('[data-del]').forEach(b => b.onclick = async () => { if (confirm('حذف الحساب؟') && await run(sb.from('profiles').delete().eq('id', b.dataset.del), 'انحذف')) mUsers(root); });
  $('#bc', root).onclick = () => printBarcodes((data || []).filter(u => u.approved).map(u => ({ code: u.barcode, label: u.full_name })));
}
const mAudit = crud({ title: 'سجل التعديلات', table: 'audit_log', order: 'at', add: false, edit: false, del: false, cols: [['at', 'الوقت', fdate], ['table_name', 'الجدول'], ['action', 'العملية'], ['user_id', 'المستخدم', v => esc(String(v || '').slice(0, 8))], ['row_id', 'السطر', v => esc(String(v).slice(0, 8))]] });

/* ===================== الرئيسية ===================== */
async function mHome(root) {
  const cnt = async (t, f) => { let q = sb.from(t).select('*', { count: 'exact', head: true }); if (f) q = f(q); const { count } = await q; return count ?? 0; };
  const k = [];
  if (hasRole([...DEPT, ...STORE, ...PURCH, ...ADMIN])) { k.push(['طلبات مفتوحة', await cnt('requests', q => q.in('stage', ['submitted', 'store', 'purchasing']))]); }
  if (hasRole([...VEH, ...ADMIN])) k.push(['آليات خارج المجمع', await cnt('vehicles', q => q.eq('status', 'out'))]);
  if (hasRole([...STORE, ...ADMIN, 'security'])) k.push(['شاحنات واصلة', await cnt('incoming_trucks', q => q.eq('state', 'arrived'))]);
  if (hasRole([...ATT, ...ADMIN])) k.push(['حاضرين اليوم', await cnt('attendance', q => q.eq('day', today()).eq('present', true))]);
  if (hasRole(['accounts_head', ...ADMIN])) { const { data } = await sb.from('cash_ledger').select('direction,amount').neq('ref', 'legacy').eq('box', 'main'); k.push(['رصيد الصندوق', fmt((data || []).reduce((a, r) => a + (r.direction === 'in' ? 1 : -1) * Number(r.amount), 0))]); }
  if (hasRole(['sales_head', 'gm1', 'gm2'])) k.push(['حجوزات', await cnt('bookings')]);
  const { data: nt } = await sb.from('notifications').select('*').order('created_at', { ascending: false }).limit(15);
  root.innerHTML = `<div class="card"><b>أهلاً ${esc(ME.full_name)}</b><div class="mut">${esc(ROLES[ME.role])} — ${esc(SITES.find(s => s.id === ME.site_id)?.name || '')}</div></div><div class="grid">${k.map(([l, v]) => `<div class="kpi"><span>${l}</span><b>${v}</b></div>`).join('')}</div>
   <div class="card" style="margin-top:10px"><h3>الإشعارات</h3>${table([['created_at', 'الوقت', fdate], ['title', 'الإشعار'], ['body', 'التفاصيل', v => /^https?:/.test(v || '') ? link(v) : esc(v)]], nt || [])}</div>
   ${isOwner() ? '<div class="card"><button class="btn sec" id="bk">⬇ نسخة احتياطية Excel</button> <button class="btn sec" id="pr">🖨 طباعة</button> <button class="btn sec" id="late">فحص الطلبات المتأخرة</button></div>' : ''}`;
  if (isOwner()) {
    $('#pr', root).onclick = () => window.print();
    $('#late', root).onclick = async () => { await run(sb.rpc('notify_late_requests'), 'تم'); mount(); };
    $('#bk', root).onclick = async () => { const wb = XLSX.utils.book_new(); for (const t of ['materials', 'stock_moves', 'requests', 'invoices', 'vehicles', 'fuel_logs', 'gate_logs', 'workers', 'attendance', 'cash_ledger', 'advances', 'apartments', 'customers', 'bookings', 'sales_payments']) { const { data } = await sb.from(t).select('*').limit(10000); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data || []), t.slice(0, 31)); } XLSX.writeFile(wb, `نسخة-احتياطية-${today()}.xlsx`); };
  }
}

/* ===================== قائمة الوحدات حسب الصفة ===================== */
const MODS = [
  ['home', '🏠 الرئيسية', 'all', mHome],
  ['requests', 'الطلبات', [...DEPT, ...STORE, ...PURCH, ...ADMIN], mRequests],
  ['materials', 'المواد', [...STORE, ...ADMIN], mMaterials],
  ['moves', 'المدخلات والمخرجات', [...STORE, ...ADMIN], mMoves],
  ['stocktake', 'الجرد', [...STORE, ...ADMIN], mStocktake],
  ['trucks', 'الشاحنات الواصلة', [...STORE, 'security', ...ADMIN], mTrucks],
  ['invoices', 'الفواتير', [...PURCH, 'storekeeper', 'store_main', 'accounts_head', ...ADMIN], mInvoices],
  ['suppliers', 'الموردين', [...PURCH, 'accounts_head', ...ADMIN], mSuppliers],
  ['prices', 'أسعار المواد', [...PURCH, 'accounts_head', ...ADMIN], mPrices],
  ['gps', 'تتبع GPS', ['purchasing_head', ...ADMIN], mGps],
  ['gate', 'البوابة', ['security', ...ADMIN], mGate],
  ['external', 'الآليات الخارجية', ['security', ...ADMIN], mExternal],
  ['vehicles', 'الآليات', [...VEH, ...ADMIN], mVehicles],
  ['fuel', 'الكاز', ['fuel_officer', 'store_vehicles', ...ADMIN], mFuel],
  ['attendance', 'الحضور', [...ATT, ...ADMIN], mAttendance],
  ['workers', 'العمال', ['project_admin', 'accounts_head', ...ADMIN], mWorkers],
  ['payroll', 'الرواتب', ['project_admin', 'accounts_head', ...ADMIN], mPayroll],
  ['cash', 'الصندوق والدفتر', ['accounts_head', ...ADMIN], mCash],
  ['disb', 'صندوق الصرف', ['disbursement'], mDisb],
  ['advances', 'السلف', ['accounts_head', ...ADMIN], mAdvances],
  ['contractors', 'المقاولين', ['accounts_head', ...ADMIN], mContractorPay],
  ['station', 'سلفة الكاز', ['accounts_head', 'fuel_officer', ...ADMIN], mStation],
  ['bookings', 'الحجوزات', [...SALES, 'gm1', 'gm2', 'project_manager', 'accounts_head'], mBookings],
  ['apartments', 'الشقق', [...SALES, 'gm1', 'gm2', 'project_manager'], mApartments],
  ['customers', 'الزبائن والعقود', [...SALES, 'gm1', 'gm2', 'project_manager'], mCustomers],
  ['users', 'المستخدمين', ADMIN, mUsers],
  ['audit', 'سجل التعديلات', [], mAudit],
];
let mount = () => { };

/* ===================== الدخول والتسجيل ===================== */
function loginScreen() {
  $('#app').innerHTML = `<div class="login"><div class="card"><h2 style="text-align:center;margin:0 0 8px">نظام شركة المنصور</h2>
    <div class="tabs"><button class="btn" id="t1">دخول</button><button class="btn sec" id="t2">تسجيل جديد</button></div>
    <div id="box"></div><div class="err" id="er"></div></div></div>`;
  const log = () => {
    $('#box').innerHTML = `<label>اسم المستخدم أو رقم الدخول (8 أرقام) أو الباركود</label><input id="u" autocomplete="username"><label>كلمة السر</label><input id="p" type="password" autocomplete="current-password"><button class="btn" id="go" style="margin-top:12px;width:100%">دخول</button>`;
    $('#go').onclick = async () => {
      $('#er').textContent = ''; const code = $('#u').value.trim(); if (!code || !$('#p').value) return;
      const { data: em } = await sb.rpc('login_email', { code });
      const email = em || (code + '@mansour.local');
      const { error } = await sb.auth.signInWithPassword({ email, password: $('#p').value });
      if (error) $('#er').textContent = 'اسم المستخدم أو كلمة السر غلط'; else boot();
    };
  };
  const reg = () => {
    $('#box').innerHTML = `<label>الاسم الكامل</label><input id="n"><label>اسم المستخدم (إنكليزي بدون مسافات)</label><input id="u" autocapitalize="none"><label>رقم الهاتف</label><input id="ph" inputmode="tel"><label>كلمة السر (6 أحرف على الأقل)</label><input id="p" type="password"><label>الموقع</label><select id="s"><option value="1">المنصور ستي</option><option value="2">مجمع الأميرات ستي (الفلوجة)</option></select><button class="btn" id="go" style="margin-top:12px;width:100%">سجّل وانتظر الموافقة</button>`;
    $('#go').onclick = async () => {
      const u = $('#u').value.trim().toLowerCase(); if (!/^[a-z0-9._-]{3,}$/.test(u) || !$('#n').value) return $('#er').textContent = 'تأكد من الاسم واسم المستخدم (حروف إنكليزية وأرقام)';
      const { error } = await sb.auth.signUp({ email: u + '@mansour.local', password: $('#p').value, options: { data: { full_name: $('#n').value, phone: $('#ph').value, site_id: Number($('#s').value) } } });
      if (error) $('#er').textContent = errMsg(error); else { await sb.auth.signOut(); $('#box').innerHTML = '<div class="warn">انسجلت. انتظر موافقة المسؤول، وبعدها تدخل.</div>'; }
    };
  };
  $('#t1').onclick = () => { $('#t1').className = 'btn'; $('#t2').className = 'btn sec'; log(); };
  $('#t2').onclick = () => { $('#t2').className = 'btn'; $('#t1').className = 'btn sec'; reg(); };
  log();
}
async function boot() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) return loginScreen();
  const { data: p } = await sb.from('profiles').select('*').eq('id', session.user.id).single();
  if (!p) { await sb.auth.signOut(); return loginScreen(); }
  if (!p.approved) {
    $('#app').innerHTML = `<div class="login"><div class="card"><h3>حسابك بانتظار الموافقة</h3><p>رقم دخولك: <b>${esc(p.login_number)}</b><br>باركودك: <b>${esc(p.barcode)}</b></p><button class="btn" id="lo">خروج</button></div></div>`;
    $('#lo').onclick = async () => { await sb.auth.signOut(); loginScreen(); }; return;
  }
  ME = p; SITES = (await sb.from('sites').select('*')).data || [];
  const mods = MODS.filter(m => m[0] === 'audit' ? isOwner() : hasRole(m[2]));
  mount = async () => {
    $('#app').innerHTML = `<header><h1>نظام المنصور</h1>${isOwner() ? `<select id="sw">${SITES.map(s => `<option value="${s.id}" ${s.id === ME.site_id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>` : `<span class="mut" style="color:#cfe">${esc(SITES.find(s => s.id === ME.site_id)?.name || '')}</span>`}<button id="lo">خروج</button></header>
      <nav>${mods.map(m => `<button data-v="${m[0]}" class="${m[0] === VIEW ? 'on' : ''}">${m[1]}</button>`).join('')}</nav><main id="main"></main>`;
    $('#lo').onclick = async () => { await sb.auth.signOut(); location.reload(); };
    const sw = $('#sw'); if (sw) sw.onchange = async () => { ME.site_id = Number(sw.value); await sb.from('profiles').update({ site_id: ME.site_id }).eq('id', ME.id); Object.keys(refCache).forEach(k => delete refCache[k]); mount(); };
    document.querySelectorAll('nav [data-v]').forEach(b => b.onclick = () => { VIEW = b.dataset.v; mount(); });
    const m = mods.find(x => x[0] === VIEW) || mods[0]; VIEW = m[0];
    const root = $('#main'); root.innerHTML = '<div class="mut">...</div>';
    try { await m[3](root); } catch (e) { root.innerHTML = `<div class="card err">${esc(errMsg(e))}</div>`; console.error(e); }
  };
  mount();
  // إشعارات فورية
  if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission();
  sb.channel('nt').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications' }, pl => {
    if (pl.new.site_id !== ME.site_id && !isOwner()) return;
    toast('🔔 ' + pl.new.title + ' — ' + (pl.new.body || ''), 5000);
    try { if (Notification.permission === 'granted') new Notification(pl.new.title, { body: pl.new.body || '' }); } catch { }
  }).subscribe();
  // GPS للمشتريات والسواق
  if (['purchasing_head', 'buyer', 'driver'].includes(ME.role) && navigator.geolocation) {
    const send = () => navigator.geolocation.getCurrentPosition(p => sb.from('gps_points').insert({ lat: p.coords.latitude, lng: p.coords.longitude }), () => { }, { enableHighAccuracy: true });
    send(); setInterval(send, 120000);
  }
}
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => { });
boot();
