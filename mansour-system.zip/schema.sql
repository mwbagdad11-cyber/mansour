-- =====================================================
-- نظام شركة المنصور — قاعدة البيانات (Supabase / PostgreSQL)
-- شغّل الملف كامل مرة وحدة بـ SQL Editor
-- =====================================================
create extension if not exists pgcrypto;

-- ---------- المواقع ----------
create table sites (
  id serial primary key,
  name text not null unique
);
insert into sites(name) values ('المنصور ستي'), ('مجمع الأميرات ستي (الفلوجة)');

-- ---------- المستخدمون والصفات ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  full_name text not null,
  phone text,
  role text not null default 'pending',
  site_id int references sites(id) default 1,
  approved boolean not null default false,
  login_number text unique,          -- رقم دخول 8 أرقام
  barcode text unique,               -- باركود الموظف
  created_by uuid,
  created_at timestamptz default now()
);

create or replace function my_role() returns text language sql stable security definer set search_path=public as
$$ select role from profiles where id = auth.uid() and approved $$;
create or replace function my_site() returns int language sql stable security definer set search_path=public as
$$ select site_id from profiles where id = auth.uid() and approved $$;
create or replace function is_owner() returns boolean language sql stable security definer set search_path=public as
$$ select coalesce((select role in ('owner','developer') from profiles where id=auth.uid() and approved), false) $$;
create or replace function has_role(r text[]) returns boolean language sql stable security definer set search_path=public as
$$ select is_owner() or coalesce(my_role() = any(r), false) $$;

-- دخول برقم الدخول أو الباركود: يرجّع الإيميل الداخلي فقط (كلمة السر تبقى مطلوبة)
create or replace function login_email(code text) returns text language sql security definer set search_path=public as
$$ select username || '@mansour.local' from profiles where login_number = code or barcode = code or username = code limit 1 $$;
grant execute on function login_email(text) to anon, authenticated;

-- إنشاء ملف المستخدم تلقائياً عند التسجيل
create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
declare uname text := split_part(new.email,'@',1);
begin
  insert into profiles(id, username, full_name, phone, role, approved, login_number, barcode, site_id)
  values (new.id, uname,
          coalesce(new.raw_user_meta_data->>'full_name', uname),
          new.raw_user_meta_data->>'phone',
          'pending', false,
          lpad((floor(random()*100000000))::int::text, 8, '0'),
          'U-' || upper(substr(md5(new.id::text),1,8)),
          coalesce((new.raw_user_meta_data->>'site_id')::int, 1));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

alter table profiles enable row level security;
create policy p_sel on profiles for select using (id = auth.uid() or is_owner() or has_role(array['project_manager','gm1','gm2','project_admin','store_main','store_vehicles','purchasing_head','accounts_head','sales_head','foreman']));
create policy p_upd on profiles for update using (is_owner() or has_role(array['project_manager','gm1','gm2','project_admin']));
create policy p_del on profiles for delete using (is_owner());

-- ---------- سجل التعديلات ----------
create table audit_log (
  id bigserial primary key,
  at timestamptz default now(),
  user_id uuid default auth.uid(),
  table_name text, action text, row_id text, old_data jsonb, new_data jsonb
);
alter table audit_log enable row level security;
create policy a_sel on audit_log for select using (is_owner());

create or replace function audit_fn() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into audit_log(table_name, action, row_id, old_data, new_data)
  values (tg_table_name, tg_op,
    coalesce((case when tg_op='DELETE' then old.id else new.id end)::text,''),
    case when tg_op in ('UPDATE','DELETE') then to_jsonb(old) end,
    case when tg_op in ('INSERT','UPDATE') then to_jsonb(new) end);
  return coalesce(new, old);
end $$;

-- ---------- جداول العمل (كلها فيها site_id و client_token لمنع التكرار) ----------
-- ملاحظة: client_token يتولد من الواجهة، والضغطة المكررة تنرفض بـ unique

-- المخزن
create table materials (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  name text not null, unit text default 'قطعة', store text default 'main', -- main | vehicles
  qty numeric default 0, building text, notes text, created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table stock_moves (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  material_id uuid references materials(id), direction text check (direction in ('in','out','repair_in','repair_out')),
  qty numeric not null, vehicle_id uuid, building text, receipt_photo text, notes text,
  created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table stocktakes (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  material_id uuid references materials(id), counted numeric, system_qty numeric, notes text,
  created_by uuid default auth.uid(), created_at timestamptz default now()
);

-- الطلبات والمشتريات
create table requests (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  dept text, material text not null, qty numeric, unit text, work_place text, building text, photo text, notes text,
  stage text default 'submitted', -- submitted | store | purchasing | received | done | rejected
  stage_by uuid, stage_at timestamptz default now(), from_vehicle_store boolean default false,
  created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table request_log (
  id bigserial primary key, request_id uuid references requests(id) on delete cascade,
  stage text, note text, by_user uuid default auth.uid(), at timestamptz default now()
);
create table suppliers (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  name text not null, phone text, notes text, created_at timestamptz default now()
);
create table invoices (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  supplier text, invoice_no text, inv_date date default current_date, total numeric default 0,
  payment text default 'cash', -- cash | credit
  status text default 'draft', -- draft | review | approved | rejected
  photo text, lines jsonb default '[]', building text, buyer uuid default auth.uid(), notes text,
  image_hash text, created_at timestamptz default now()
);
create unique index inv_dup on invoices(site_id, supplier, invoice_no) where invoice_no is not null and invoice_no <> '';
create table price_history (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  material text, supplier text, price numeric, at date default current_date, created_at timestamptz default now()
);
create table gps_points (
  id bigserial primary key, site_id int default my_site(), user_id uuid default auth.uid(),
  lat double precision, lng double precision, at timestamptz default now()
);

-- الآليات والوقود والبوابة
create table vehicles (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  name text not null, plate text, kind text, barcode text unique default 'V-' || upper(substr(md5(random()::text),1,6)),
  status text default 'inside', -- inside | out | loaded
  fuel_rate numeric, notes text, created_at timestamptz default now()
);
create table vehicle_trips (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  vehicle_id uuid references vehicles(id), driver text, material text, qty numeric,
  event text check (event in ('enter','load','exit','arrive')), destination text, notes text,
  created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table vehicle_costs (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  vehicle_id uuid references vehicles(id), kind text, amount numeric, days int, notes text,
  created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table fuel_logs (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  direction text check (direction in ('in','out')), liters numeric not null,
  vehicle_id uuid references vehicles(id), station text, price_per_liter numeric,
  created_by uuid default auth.uid(), created_at timestamptz default now()
);
create view fuel_balance with (security_invoker=on) as
  select site_id, coalesce(sum(case when direction='in' then liters else -liters end),0) as balance from fuel_logs group by site_id;

create table gate_logs (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  vehicle_id uuid references vehicles(id), event text check (event in ('enter','exit')),
  driver text, material text, qty numeric, warning text, notes text,
  created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table external_vehicles (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  plate text not null, kind text, company text, reason text, destination text,
  plate_photo text, entered_at timestamptz default now(), exited_at timestamptz,
  exit_state text, -- empty | loaded
  exit_permit boolean default false, is_supply boolean default false, banned boolean default false,
  created_by uuid default auth.uid()
);
create table banned_plates (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), plate text unique, reason text
);
create table incoming_trucks (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  plate text, supplier text, material text, qty numeric, state text default 'arrived', -- arrived | unloaded
  receipt_photo text, created_at timestamptz default now()
);

-- الحضور والكادر
create table workers (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  name text not null, nationality text default 'عراقي', trade text, number text, fingerprint_id text,
  daily_wage numeric default 0, contractor text, active boolean default true, created_at timestamptz default now()
);
create table attendance (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(),
  worker_id uuid references workers(id), day date default current_date,
  present boolean default true, hours numeric default 8, source text default 'manual', needs_review boolean default false,
  recorded_by uuid default auth.uid(), unique(worker_id, day)
);
create table payroll_items (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  worker_id uuid references workers(id), kind text check (kind in ('salary','deduction','advance','cut')),
  amount numeric, period text, notes text, posted boolean default false, created_at timestamptz default now()
);

-- الحسابات
create table cash_ledger (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  day date default current_date, direction text check (direction in ('in','out')), category text,
  amount numeric not null, currency text default 'IQD', ref text, notes text,
  status text default 'approved', reverses uuid references cash_ledger(id),
  box text default 'main', -- main | usd | disbursement:<user>
  created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table cash_closings (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), day date, total_in numeric, total_out numeric,
  balance numeric, closed_by uuid default auth.uid(), unique(site_id, day)
);
create table advances (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  party_kind text, party text, amount numeric, settled numeric default 0, notes text, created_at timestamptz default now()
);
create table contractor_payments (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  contractor text, amount numeric, notes text, created_at timestamptz default now()
);
create table disbursement_boxes (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), user_id uuid, balance numeric default 0
);
create table fuel_station_statements (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  period text, liters numeric, amount numeric, price_per_liter numeric, lines jsonb default '[]', photo text,
  status text default 'review', created_at timestamptz default now()
);

-- المبيعات
create table buildings (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(),
  code text, investor_share boolean default false, unique(site_id, code)
);
create table apartments (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  building text, floor int, number text, area numeric, status text default 'free', -- free | reserved | sold
  created_at timestamptz default now()
);
create table customers (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  name text not null, phone text, id_doc text, kind text default 'buyer', notes text, created_at timestamptz default now()
);
create table bookings (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  customer_id uuid references customers(id), apartment_id uuid references apartments(id),
  area numeric, meter_price numeric default 1750000, discount numeric default 0, discount_reason text,
  total numeric, down_payment numeric default 90000000, handover_payment numeric default 50000000,
  installment numeric default 2000000, months int default 84, due_day int,
  start_date date default current_date, contract_url text, created_by uuid default auth.uid(), created_at timestamptz default now()
);
create table sales_payments (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), client_token text unique,
  booking_id uuid references bookings(id), amount numeric not null, kind text default 'installment',
  services numeric default 0, day date default current_date, notes text, created_by uuid default auth.uid()
);
create table contract_files (
  id uuid primary key default gen_random_uuid(), site_id int default my_site(), customer_id uuid references customers(id),
  title text, file_url text, created_at timestamptz default now()
);

-- الإشعارات
create table notifications (
  id bigserial primary key, site_id int default my_site(), title text, body text, kind text,
  created_at timestamptz default now()
);

-- =====================================================
-- RLS: كل موقع بياناته منفصلة + صلاحيات حسب الصفة
-- =====================================================
do $$
declare t text;
  general text[] := array['materials','stock_moves','stocktakes','requests','suppliers','invoices','price_history','gps_points',
    'vehicles','vehicle_trips','vehicle_costs','fuel_logs','gate_logs','external_vehicles','banned_plates','incoming_trucks',
    'workers','attendance','notifications','buildings','apartments'];
  money text[] := array['cash_ledger','cash_closings','advances','contractor_payments','disbursement_boxes','fuel_station_statements'];
  hr text[] := array['payroll_items'];
  sales text[] := array['customers','bookings','sales_payments','contract_files'];
begin
  foreach t in array general || money || hr || sales loop
    execute format('alter table %I enable row level security', t);
    -- القراءة: نفس الموقع (والمالك كلشي)
    execute format($f$create policy %I on %I for select using (is_owner() or site_id = my_site())$f$, t||'_sel', t);
    -- الحذف: المالك بس
    execute format($f$create policy %I on %I for delete using (is_owner())$f$, t||'_del', t);
  end loop;

  foreach t in array general loop
    execute format($f$create policy %I on %I for insert with check (my_role() is not null and (is_owner() or site_id = my_site()))$f$, t||'_ins', t);
    execute format($f$create policy %I on %I for update using (is_owner() or site_id = my_site())$f$, t||'_upd', t);
  end loop;

  foreach t in array money loop
    execute format($f$create policy %I on %I for insert with check (has_role(array['accounts_head','disbursement','project_manager','gm1','gm2']) and (is_owner() or site_id = my_site()))$f$, t||'_ins', t);
    execute format($f$create policy %I on %I for update using (has_role(array['accounts_head']) and (is_owner() or site_id = my_site()))$f$, t||'_upd', t);
  end loop;
  -- مسؤولة الصرف ما تشوف الحسابات الرئيسية: تشوف صندوقها بس
  drop policy cash_ledger_sel on cash_ledger;
  create policy cash_ledger_sel on cash_ledger for select using (
    is_owner() or (site_id = my_site() and (
      has_role(array['accounts_head','project_manager','gm1','gm2'])
      or (my_role()='disbursement' and box = 'disbursement:' || auth.uid()::text))));

  foreach t in array hr loop
    execute format($f$create policy %I on %I for insert with check (has_role(array['project_admin','accounts_head','project_manager','gm1','gm2']) and (is_owner() or site_id = my_site()))$f$, t||'_ins', t);
    execute format($f$create policy %I on %I for update using (has_role(array['project_admin','accounts_head']) and (is_owner() or site_id = my_site()))$f$, t||'_upd', t);
  end loop;

  foreach t in array sales loop
    execute format($f$create policy %I on %I for insert with check (has_role(array['sales_head','sales_staff','gm1','gm2','project_manager']) and (is_owner() or site_id = my_site()))$f$, t||'_ins', t);
    execute format($f$create policy %I on %I for update using (has_role(array['sales_head','gm1','gm2']) and (is_owner() or site_id = my_site()))$f$, t||'_upd', t);
  end loop;
  drop policy customers_sel on customers; drop policy bookings_sel on bookings;
  drop policy sales_payments_sel on sales_payments; drop policy contract_files_sel on contract_files;
  foreach t in array sales loop
    execute format($f$create policy %I on %I for select using (has_role(array['sales_head','sales_staff','gm1','gm2','project_manager','accounts_head']) and (is_owner() or site_id = my_site()))$f$, t||'_sel2', t);
  end loop;

  -- سجل التعديلات على كل الجداول
  foreach t in array general || money || hr || sales loop
    if t not in ('gps_points','notifications') then
      execute format('create trigger %I after insert or update or delete on %I for each row execute function audit_fn()', 'aud_'||t, t);
    end if;
  end loop;
end $$;

-- request_log
alter table request_log enable row level security;
create policy rl_sel on request_log for select using (true);
create policy rl_ins on request_log for insert with check (my_role() is not null);

-- sites
alter table sites enable row level security;
create policy sites_sel on sites for select using (true);

-- الحركات المعتمدة بالصندوق ما تنحذف ولا تنعدل (تتصحح بحركة عكس)
create or replace function protect_ledger() returns trigger language plpgsql as $$
begin
  if tg_op = 'DELETE' and old.status = 'approved' then
    raise exception 'الحركة المعتمدة ما تنحذف — سوّي حركة عكس';
  end if;
  if tg_op = 'UPDATE' and old.status = 'approved' and (new.amount <> old.amount or new.direction <> old.direction) then
    raise exception 'الحركة المعتمدة ما تنعدل — سوّي حركة عكس';
  end if;
  return coalesce(new, old);
end $$;
create trigger protect_cash before update or delete on cash_ledger for each row execute function protect_ledger();

-- مسؤولة الصرف ما تصرف أكثر من رصيدها
create or replace function check_disbursement() returns trigger language plpgsql security definer set search_path=public as $$
declare bal numeric;
begin
  if new.box like 'disbursement:%' and new.direction = 'out' then
    select coalesce(sum(case when direction='in' then amount else -amount end),0) into bal
      from cash_ledger where box = new.box and site_id = new.site_id;
    if bal < new.amount then raise exception 'الرصيد ما يكفي (المتوفر %)', bal; end if;
  end if;
  return new;
end $$;
create trigger chk_disb before insert on cash_ledger for each row execute function check_disbursement();

-- الآلية: تحذير إذا الزر ما يطابق حالتها + تحديث الحالة
create or replace function gate_apply() returns trigger language plpgsql security definer set search_path=public as $$
declare st text;
begin
  select status into st from vehicles where id = new.vehicle_id;
  if new.event = 'exit' and st = 'out' then new.warning := 'الآلية مسجّلة خارج المجمع أصلاً'; end if;
  if new.event = 'enter' and st = 'inside' then new.warning := 'الآلية مسجّلة داخل المجمع أصلاً'; end if;
  update vehicles set status = case when new.event='exit' then 'out' else 'inside' end where id = new.vehicle_id;
  if new.event = 'exit' then
    insert into notifications(site_id, title, body, kind) values (new.site_id, 'خروج آلية', coalesce(new.material,'')||' '||coalesce(new.qty::text,''), 'gate');
  end if;
  return new;
end $$;
create trigger gate_apply_t before insert on gate_logs for each row execute function gate_apply();

-- الآلية الخارجية: محمّلة بدون إذن = تنبيه، والتوريد يصير شاحنة واصلة
create or replace function ext_apply() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if exists(select 1 from banned_plates where site_id = new.site_id and plate = new.plate) then new.banned := true;
    insert into notifications(site_id,title,body,kind) values (new.site_id,'سيارة ممنوعة',new.plate,'gate'); end if;
  if tg_op = 'INSERT' and new.is_supply then
    insert into incoming_trucks(site_id, plate, supplier, material) values (new.site_id, new.plate, new.company, new.reason);
    insert into notifications(site_id,title,body,kind) values (new.site_id,'شاحنة واصلة',new.plate,'truck');
  end if;
  if tg_op = 'UPDATE' and new.exited_at is not null and old.exited_at is null and new.exit_state = 'loaded' and not new.exit_permit then
    insert into notifications(site_id,title,body,kind) values (new.site_id,'خروج محمّل بدون إذن',new.plate,'gate');
  end if;
  return new;
end $$;
create trigger ext_apply_t before insert or update on external_vehicles for each row execute function ext_apply();

-- طلب متأخر بمرحلة وحدة (تُستدعى يومياً من Cron أو يدوياً)
create or replace function notify_late_requests() returns void language sql security definer set search_path=public as $$
  insert into notifications(site_id,title,body,kind)
  select site_id, 'طلب متأخر', material || ' — مرحلة ' || stage, 'late' from requests
  where stage in ('submitted','store','purchasing') and stage_at < now() - interval '1 day';
$$;

-- تحديث رصيد المخزن تلقائياً
create or replace function stock_apply() returns trigger language plpgsql security definer set search_path=public as $$
begin
  update materials set qty = qty + case new.direction when 'in' then new.qty when 'out' then -new.qty when 'repair_in' then -new.qty else new.qty end
  where id = new.material_id;
  return new;
end $$;
create trigger stock_apply_t after insert on stock_moves for each row execute function stock_apply();

-- تحذير الكاز المكرر
create or replace function fuel_dup() returns trigger language plpgsql as $$
begin
  if exists (select 1 from fuel_logs where vehicle_id = new.vehicle_id and liters = new.liters and direction = new.direction
             and created_at > now() - interval '10 minutes') then
    raise exception 'تحذير: نفس التعبئة انسجلت قبل شوي';
  end if;
  return new;
end $$;
create trigger fuel_dup_t before insert on fuel_logs for each row execute function fuel_dup();

-- Realtime للإشعارات
alter publication supabase_realtime add table notifications;

-- ---------- أول مستخدم: بعد ما تسجّل حسابك شغّل هذا بس ----------
-- update profiles set role='owner', approved=true where username='اسم_مستخدمك';

-- ---------- الأبنية T1..T22 للموقعين (T1-T4 حصة المستثمر) ----------
insert into buildings(site_id, code, investor_share)
select s.id, 'T'||g, g <= 4 from sites s, generate_series(1,22) g on conflict do nothing;

-- ---------- دفعات المبيعات تنزل وارد بصندوق الموقع تلقائياً ----------
create or replace function sales_to_cash() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into cash_ledger(site_id, direction, category, amount, ref, client_token, notes, box)
  values (new.site_id, 'in', 'مبيعات', new.amount + coalesce(new.services,0), 'sale:'||new.id, 'sale-'||new.id, 'دفعة حجز', 'main');
  return new;
end $$;
create trigger sales_to_cash_t after insert on sales_payments for each row execute function sales_to_cash();

-- ---------- Storage: bucket اسمه files (Public) ----------
insert into storage.buckets(id, name, public) values ('files','files',true) on conflict do nothing;
create policy files_ins on storage.objects for insert to authenticated with check (bucket_id = 'files');
create policy files_sel on storage.objects for select using (bucket_id = 'files');
