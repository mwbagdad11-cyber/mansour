// عدّل هاي القيم من Supabase → Project Settings → API
window.APP_CONFIG = {
  url: "https://YOUR-PROJECT.supabase.co",
  key: "YOUR-ANON-PUBLIC-KEY",
  bucket: "files"            // اسم الـ Storage bucket (Public)
};
