// Supabase Edge Function: ai-read
// تقرأ الصور والملفات بواسطة Claude وترجّع JSON.
// النشر:  supabase functions deploy ai-read
// المفتاح: supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PROMPTS: Record<string, string> = {
  request_sheet:
    'ورقة طلب مواد مكتوبة بخط اليد. استخرج المواد. رجّع JSON فقط بهذا الشكل: {"items":[{"material":"","qty":0,"unit":""}]}',
  invoice:
    'فاتورة أو وصل شراء. رجّع JSON فقط: {"supplier":"","invoice_no":"","total":0,"payment":"cash|credit","lines":[{"material":"","qty":0,"price":0}]}',
  attendance_sheet:
    'ورقة حضور فورمن. الأسماء بالترتيب، وعلامة X أو شطب تعني غياب. رجّع JSON فقط: {"rows":[{"name":"","absent":false}]}',
  station_statement:
    'كشف محطة وقود. رجّع JSON فقط: {"period":"","liters":0,"amount":0,"price_per_liter":0,"lines":[{"date":"","vehicle":"","liters":0,"amount":0}]}',
  plate:
    'صورة لوحة سيارة عراقية. رجّع JSON فقط: {"plate":"","kind":""}',
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    // لازم مستخدم مسجّل دخول
    if (!req.headers.get("authorization")) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: cors });
    }
    const { kind, data, media_type } = await req.json();
    const prompt = PROMPTS[kind];
    if (!prompt || !data) {
      return new Response(JSON.stringify({ error: "bad request" }), { status: 400, headers: cors });
    }
    const isPdf = media_type === "application/pdf";
    const block = isPdf
      ? { type: "document", source: { type: "base64", media_type, data } }
      : { type: "image", source: { type: "base64", media_type: media_type || "image/jpeg", data } };

    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: Deno.env.get("AI_MODEL") ?? "claude-sonnet-5-5",
        max_tokens: 4096,
        temperature: 0,
        messages: [{ role: "user", content: [block, { type: "text", text: prompt + "\nلا تكتب أي شي غير JSON." }] }],
      }),
    });
    const j = await r.json();
    const text = j?.content?.[0]?.text ?? "";
    const m = text.match(/\{[\s\S]*\}/);
    if (!m) return new Response(JSON.stringify({ error: "no json", raw: text }), { status: 502, headers: cors });
    return new Response(m[0], { headers: { ...cors, "content-type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500, headers: cors });
  }
});
